﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Net.Http;
using CrystalReportDemo.CustomToken;
using NLog;
using System.Web.Http.Cors;

namespace CrystalReportDemo.Filters
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [AttributeUsage(AttributeTargets.Class , AllowMultiple = false)]
    public class GenericAuthorizationFilter : AuthorizationFilterAttribute
    {

        TokenRepository _repoObj = new TokenRepository();
        private static Logger logger = LogManager.GetCurrentClassLogger();
         /// <summary>
        /// Public default Constructor
        /// </summary>
        public GenericAuthorizationFilter()
        {
        }

        private readonly bool _isActive = true;

        /// <summary>
        /// parameter isActive explicitly enables/disables this filetr.
        /// </summary>
        /// <param name="isActive"></param>
        public GenericAuthorizationFilter(bool isActive)
        {
            _isActive = isActive;
        }

        /// <summary>
        /// Checks basic authentication request
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnAuthorization(HttpActionContext filterContext)
        {
            
            logger.Info("In OnAuthorization method");
            if (!_isActive) return;
            var authHeader = FetchAuthHeader(filterContext);
            //if the header is null then challenge the request
            if (authHeader == null)
            {
                logger.Info("Request header is null");
                ChallengeAuthRequest(filterContext);
                return;
            }
            else
            {
                logger.Info("Request header is present");
                //header is present
                string authorizationToken = authHeader.Split(':')[0];
                string userName = authHeader.Split(':')[1];
                //if the token or username is null then challenge the request.
                if (authorizationToken == null || userName == null)
                {
                    logger.Info("Token or Username is null");
                    ChallengeAuthRequest(filterContext);
                    return;
                }
                //if the token is valid, then validate the token against the user.
                else
                {
                    logger.Info("Valid request header");
                    bool isValid = _repoObj.ValidateToken(authorizationToken, userName);
                    if (isValid)
                    {
                        return;
                    }
                    else
                    {
                        ChallengeAuthRequest(filterContext);
                        return;
                    }
                }
               
            }
            base.OnAuthorization(filterContext);
            
        }

        /// <summary>
        /// Virtual method.Can be overriden with the custom Authorization.
        /// </summary>
        /// <param name="user"></param>
        /// <param name="pass"></param>
        /// <param name="filterContext"></param>
        /// <returns></returns>
        protected virtual bool OnAuthorizeUser(string user, string pass, HttpActionContext filterContext)
        {
            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
                return false;
            return true;
        }

        /// <summary>
        /// Checks for autrhorization header in the request and parses it, creates user credentials and returns as BasicAuthenticationIdentity
        /// </summary>
        /// <param name="filterContext"></param>
      
        protected virtual string FetchAuthHeader(HttpActionContext filterContext)
        {
            logger.Info("Featching request auth value");
            string authHeaderValue = null;
            var authRequest = filterContext.Request.Headers.Authorization;
            if (authRequest != null && !String.IsNullOrEmpty(authRequest.Scheme) && authRequest.Scheme == "Bearer")
                authHeaderValue = authRequest.Parameter;
            return authHeaderValue;
            if (string.IsNullOrEmpty(authHeaderValue))
                return null;
         
        }

        /// <summary>
        /// Send the Authentication Challenge request
        /// </summary>
        /// <param name="filterContext"></param>
        private static void ChallengeAuthRequest(HttpActionContext filterContext)
        {
            logger.Info("Unauthorized.Hence challenging the request");
            var dnsHost = filterContext.Request.RequestUri.DnsSafeHost;
            filterContext.Response = filterContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            filterContext.Response.Headers.Add("WWW-Authenticate", string.Format("Barear realm=\"{0}\"", dnsHost));
        }


    }
       
}