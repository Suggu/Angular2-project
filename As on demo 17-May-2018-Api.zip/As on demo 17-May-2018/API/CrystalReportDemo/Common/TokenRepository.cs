﻿
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Text;
using System.Web;
using System.Security.Claims;
using System.Configuration;
using System.IO;
using System.Data.Entity;
using System.Linq.Expressions;
using CrystalReportDemo.Models;
using NLog;
using System.Data.SqlClient;
using System.Data.Entity.Core.EntityClient;
using System.Data;
using System.Data.Entity.Core.Objects;

namespace CrystalReportDemo.CustomToken
{
    public class TokenRepository
    {
        private readonly CMSEntities _context = new CMSEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public UserInfoModel GetUserInfo(string userId)
        {
            //var userPermission = (from userPermissions in _context.UserPermissions select userPermissions).FirstOrDefault() as UserPermission;
            return validateUser(userId);
        }

        private UserInfoModel validateUser(string userId)
        {
            //return _context.usp_UserAuthentication("ksampath", "Flip1234#", "").ToList(),model=>new UserInfoModel

            // {

            // };

            List<usp_UserAuthentication_Result> obj=_context.usp_UserAuthentication("ksampath", "Flip1234#", "").ToList();
            UserInfoModel value = new UserInfoModel();
            string Permission=string.Empty;

            //IEnumerable<Object> splist = obj.ToList();

           foreach(var result in obj)
           {
              
               Permission += result.PermissionName + ",";
               value.FullName = result.EmployeeName;
               value.Token = result.Token;
               //value.TokenExpiresOn = result.TokenExpiryDate;

           }
           Permission = Permission.Trim(',');
           value.IsAuthenticated = true;
           value.permissionList = Permission.Split(',').ToList();
           

            return value;
        

        }



        public bool ValidateToken(string authToken, string userIdToBeCompared)
        {
            //try
            //{
            //    var existingUser = (from userInfo in _context.AppUsers select userInfo).FirstOrDefault() as AppUser;
            //    if (authToken == existingUser.Token)
            //    {
            //        return true;
            //    }
            //    else
            //        return true;
            //}
            //catch (Exception ex)
            //{
            //    logger.Trace(ex);
            //}
            return true;
        }
    }
}