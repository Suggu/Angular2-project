﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace CrystalReportDemo.Common
{
    public class CommonLogger
    {
        /// <summary>
        /// Method to write exception ina text file.
        /// </summary>
        //public void HandleException(Exception ex)
        //{
        //    string filePath = ConfigurationManager.AppSettings["TraceFilePath"];

        //    using (StreamWriter writer = new StreamWriter(filePath, true))
        //    {
        //        writer.WriteLine("Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
        //           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
        //        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
        //    }
        //}
        //public void Log(string msg)
        //{
        //    string filePath = ConfigurationManager.AppSettings["LogFilePath"];

        //    using (StreamWriter writer = new StreamWriter(filePath, true))
        //    {
        //        writer.WriteLine("Message :" + msg + "<br/>" + Environment.NewLine + 
        //           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
        //        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
        //    }
        //}
    }
}