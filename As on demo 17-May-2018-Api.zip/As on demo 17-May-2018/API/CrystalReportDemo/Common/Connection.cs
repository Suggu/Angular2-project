﻿using CrystalReportDemo.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace CrystalReportDemo.Common
{
    public class Connection
    {

        public string connectionString =
            ConfigurationManager.AppSettings["ConnectionString"];

        // Provide the query string with a parameter placeholder.
        // string queryString =
        // "select Value from lexicon where fieldname = 'StudyStatus' order by value asc;";


        // Specify the parameter value.        
        public DataSet GetPersonnelInfo(string studyNumber)
        {

            string personnelString = @"SELECT  PersonnelRowId,
        StudyRowId,
        EmployeeRowId = CASE WHEN Employee.EmployeeRowId IS NULL THEN 11585
                             ELSE Personnel.EmployeeRowId
                        END,
     Employee = CASE WHEN Employee.EmployeeRowId IS NULL then ''
                             ELSE RTRIM(Employee.LastName) + ', ' + RTRIM(Employee.FirstName)
                        END,
        PersonnelTypeRowId,
        PersonnelType = Lexicon.Value,
        Rank,
        DeptCode = CostCenterRowId,
        Personnel.Comments
FROM    Personnel (NOLOCK)
        JOIN Lexicon (NOLOCK)
          ON Personnel.PersonnelTypeRowId = Lexicon.LexiconRowId
        LEFT OUTER JOIN Employee (NOLOCK)
          ON Personnel.EmployeeRowId = Employee.EmployeeRowId
WHERE  StudyRowId=(select StudyRowId from StudyInfo where StudyId=@StudyNumber) order by PersonnelRowId";
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(personnelString, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetStudy(string studyNumber)
        {
            string searchString = @"SELECT distinct [StudyId],[s].[CompoundId],[s].[Iteration],[s].[ProtocolNum],[s].[AssayMod],[s].[Status],[StudyTypeTxt],
[s].[Recovery],[MatrixTxt],[TestSystemTxt],[StrainTxt],
[RouteTxt],[s].[Duration],
[ProtocolSign] As [Protocol_Signed],[StudyInitiation] AS [Study_Start],[StudyTermination] As [Study_End],
[FinalArchive] As [Final_Rpt_Signed],
[s].[Title],
[Client_Name],[s].[CompoundName],[p].[MoleculeSize],[c].[clid],[fc].[clid] As FinancialClientID,
[fc].[clname] As FinancialClientname,[s].[comments],
STUFF ((SELECT ',',(CONVERT(varchar,[p1].[ProposalNumber])+[p1].[ProposalLetter]+'-'+CONVERT(varchar,[p1].[ModificationNumber]))
 FROM  [Study] [s1] --View
Inner JOIN [ProposalInfo] [p1] ON [p1].[StudyRowId] = [s1].[StudyRowId] 
where [s].[StudyId]=[s1].[StudyId] FOR XML PATH('')),1 ,1, '')
AS [Proposal_Number]
 FROM [Study] [s] --View
                                     Inner JOIN [ProposalInfo] [p] ON [p].[StudyRowId] = [s].[StudyRowId] 
                                     Inner JOIN [client] [c] ON [c].[clrowid] = [p].[clientrowid]
                                     Inner JOIN [client] [fc] ON [fc].[clrowid] = [p].[FinclientRowId] 
where [StudyId]=@Studynumber 
GROUP BY [StudyId]
,[s].[CompoundId],[s].[Iteration],[s].[ProtocolNum],[s].[AssayMod],[s].[Status],[StudyTypeTxt],
[s].[Recovery],[MatrixTxt],[TestSystemTxt],[StrainTxt],
[RouteTxt],[s].[Duration],[ProtocolSign],[StudyInitiation],[StudyTermination],[FinalArchive],[s].[Title],
[Client_Name],[s].[CompoundName],[p].[MoleculeSize],[c].[clid],[fc].[clid],[fc].[clname],[s].[comments],(CONVERT(varchar,[p].[ProposalNumber])+[p].[ProposalLetter]+'-'+CONVERT(varchar,[p].[ModificationNumber]))
ORDER BY [c].[clid]
";

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(searchString, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);

            try
            {
                // connection.Open();
                // SqlDataReader reader = command.ExecuteReader();
                da.Fill(ds);
                //while (reader.Read())
                //{
                //    Console.WriteLine("\t{0}\t{1}\t{2}",
                //        reader[0], reader[1], reader[2]);
                //}
                //reader.Close();
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //}
            return ds;
        }

        public DataSet GetPhaseDetails(string studyNumber, string phaserowid)
        {
            DataSet ds = new DataSet();
            var query = @"select [pd].[detailtypetxt]AS [Details],[pd].[detailvalue]AS [Value],[pd].[Comments] from [phasedetail] [pd]
                                      INNER JOIN [Study][s] ON [s].[StudyRowId]=[pd].[studyrowid] WHERE [s].[StudyId] =@StudyNumber and [pd].[phaserowid]=@PhaseRowId";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            da.SelectCommand.Parameters.AddWithValue("@PhaseRowId", phaserowid);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetDateDetails(string studyNumber, string phaserowid)
        {
            DataSet ds = new DataSet();
            DataSet dsDetail = new DataSet();
            var query = @"SELECT  [DT]. [datetypetxt] AS [DateType],[DT].[datetrackedrowid] As [DTRowid],CONVERT(DATE,[DT].[scheduledstartdate],0) AS [SchStart],
CONVERT(DATE,[DT].[projectedstartdate],0) AS [ProjStart],CONVERT(DATE,[DT].[actualstartdate],0) AS [ActStart],
                                      CONVERT(DATE,[DT].[scheduledenddate],0) AS [SchedEnd],CONVERT(DATE,[DT].[projectedenddate],0) AS [ProjEnd],
CONVERT(DATE,[DT].[actualenddate],0) AS [ActEnd], [DT].[comments] AS [DTComments],[dd].[datetrackedrowid] AS [ddRowid],
                                      [dd].[datedetailtypetxt] AS [Detail],[dd].[value] AS [Value],[dd].[comments]As [DDComments]
                                      From [datetracked] [DT]
                                      INNER JOIN [phase] [p] ON [p]. [phaserowid] = [DT]. [phaserowid]
                                      INNER JOIN [Study] [s] ON [s]. [StudyRowId] = [p]. [studyrowid]
                                      INNER JOIN [datedetail][dd] ON [dd].[datetrackedrowid]=[DT].[datetrackedrowid]
                                      WHERE [s]. [StudyId] =@StudyNumber and  [p].[phaserowid]=@PhaseRowId";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            da.SelectCommand.Parameters.AddWithValue("@PhaseRowId", phaserowid);
            try
            {
                da.Fill(ds);
                var dates = ds.Tables[0];
                string dtRowid = dates.Rows[0]["DTRowid"].ToString();
                string detailsQuery = @"select [datetrackedrowid] AS [ddRowid],
                                      [dd].[datedetailtypetxt] AS [Detail],[dd].[value] AS [Value],[dd].[comments]As [DDComments] from [datedetail][dd]
									  where [dd].[datetrackedrowid]=@dtRowid";
                SqlDataAdapter daNew = new SqlDataAdapter(detailsQuery, connectionString);
                daNew.SelectCommand.Parameters.AddWithValue("@dtRowid", dtRowid);
                daNew.Fill(dsDetail);
                var dateDetail = dsDetail.Tables[0];
                ds.Tables[0].TableName = "Dates";
                ds.Tables.Add(dateDetail.Copy());               
              
                ds.Tables[1].TableName = "DateDetail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetAgencyDetails(string studyNumber)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT studyregagencyrowid, 
       studyrowid, 
       regagencytxt AS Agency, 
       comments AS Comments,
       convert(MONEY, timestamp) AS timestamp, 
       active_q
FROM studyregagency  (NOLOCK)
WHERE active_q='Y' and studyrowid=(select StudyRowId from StudyInfo where StudyId =@StudyNumber)";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetProposalDetails(string studyNumber)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT CONVERT(VARCHAR,[p].[ProposalNumber],0)+[p].[ProposalLetter]+'-'+CONVERT(VARCHAR,[P].[ModificationNumber],0) AS [proposalNumber] FROM [ProposalInfo] [p] INNER JOIN [StudyInfo] [s] ON [p].[StudyRowId] = [s].[StudyRowId]
                                      WHERE [StudyID] =@StudyNumber";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetPhaseValues(string studyNumber)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT [p].[phasetype]+'  '+ISNULL([p].[intervaltypetxt], ' ')+'  '+CONVERT(VARCHAR,[p].[interval],0)+'  '+CONVERT(VARCHAR,[p].[costcenter],0) AS [Phase], [p]. [phaserowid] FROM [phase] [p] INNER JOIN [StudyInfo] [s] ON [p].[StudyRowId] = [s].[StudyRowId]
                                      WHERE [StudyID] =@StudyNumber order by [phasetype] desc , [cc] desc";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetGuidelinesDetails(string studyNumber)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT studyguidelinerowid, 
       studyrowid, 
       guidelinetxt, 
       comments AS Comments, 
       convert(MONEY, timestamp) AS timestamp, 
       active_q
FROM studyguideline (NOLOCK)
WHERE active_q='Y' and studyrowid=(select StudyRowId from StudyInfo where StudyId = @StudyNumber)";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@StudyNumber", studyNumber);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }
        public DataSet GetStudyNumbers(string studyNumber, string clientId, string financialClientId, string title)
        {
            string filterString = string.Empty;
            if (!string.IsNullOrEmpty(studyNumber) && !string.IsNullOrEmpty(clientId) &&
                !string.IsNullOrEmpty(financialClientId) && !string.IsNullOrEmpty(title)) filterString =
                @"[StudyId] like @studyNumber AND  [c].[clid] = @clientId AND [fc].[clid] = @financialClientId 
                        AND [s].[Title] like @title ";
            else
            {
                if (!string.IsNullOrEmpty(studyNumber)) filterString += "[StudyId] like @studyNumber ";
                if (!string.IsNullOrEmpty(clientId)) filterString += "AND [c].[clid] = @clientId ";
                if (!string.IsNullOrEmpty(financialClientId)) filterString += "AND [fc].[clid] = @financialClientId ";
                if (!string.IsNullOrEmpty(title)) filterString += "AND [s].[Title] like @title ";
            }
            filterString = string.Equals(filterString.Substring(0, 3), "AND") ? filterString.Substring(4) : filterString;
            string searchString = @"SELECT [StudyId],[s].[Title],[fc].[clid]  As FinancialClientID,[c].[clid] FROM [Study] [s] --View 
                                     Inner JOIN [ProposalInfo] [p] ON [p].[StudyRowId] = [s].[StudyRowId] 
                                     Inner JOIN [client] [c] ON [c].[clrowid] = [p].[clientrowid] 
                                     Inner JOIN [client] [fc] ON [fc].[clrowid] = [p].[FinclientRowId] WHERE " + filterString + " and [p].[ModificationNumber]=1" +
          @" GROUP BY [StudyId],[s].[Title],[fc].[clid],[c].[clid] ORDER BY [StudyId]";

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(searchString, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@studyNumber", '%' + studyNumber + '%');
            da.SelectCommand.Parameters.AddWithValue("@clientId", clientId);
            da.SelectCommand.Parameters.AddWithValue("@financialClientId", financialClientId);
            da.SelectCommand.Parameters.AddWithValue("@title", '%' + title + '%');


            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        // To get the dropdown values for adding new phase.
        // To Do -- > get the table names from the query instead of hard coding it.
        public DataSet GetNewPhaseDropDownValues()
        {
            string json = string.Empty;
            DataTable phaseType = new DataTable();
            DataTable intervalType = new DataTable();
            DataTable costCenter = new DataTable();
            DataSet ds = new DataSet();
            var query = @"SELECT DISTINCT PHASETYPE FROM PHASE WHERE ACTIVE_Q = 'Y' AND PHASETYPE IS NOT NULL;";
            query = query + " SELECT DISTINCT INTERVALTYPETXT FROM PHASE WHERE ACTIVE_Q = 'Y' AND INTERVALTYPETXT IS NOT NULL;";
            query = query + " SELECT DISTINCT CC FROM PHASE WHERE ACTIVE_Q = 'Y' AND CC IS NOT NULL;";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            try
            {
                da.Fill(ds);
                ds.Tables[0].TableName = "PhaseType";
                ds.Tables[1].TableName = "IntervalType";
                ds.Tables[2].TableName = "CostCenter";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        internal DataSet GetProposal(string ProposalNumber)
        {

            string searchString = @"Select (CONVERT(varchar,[p].[ProposalNumber])+[p].[ProposalLetter]+'-'+CONVERT(varchar,[p].[ModificationNumber])) As [Proposal #],

[s].[studyid]As [Study Number],
[cc].[ccid] AS[Base Dept Code],
[cc].[Division] As [Div],
[cc].[ccsbu] As [SBU],
[p].[IndustryType],

[p].[IndustrySubType],
[p].[MarketSegment],
[cc].[ccsite] As [Site],
[p].[Title],
[c].[clid] As [Client ID],
[fc].[clid] As FinancialClientID,

[c].[clname] As [Client Name],
[fc].[clname] As [Financial Client Name],
([ct].colname+','+[ct].cofname) As [Client Contact],

([fct].colname+','+[fct].cofname) As [Financial Client Contact],
[p].[consultant] As [Consultant],[p].[ConsultantContact] As [ConsultantContact]
,
[P].[CRMMod] As [CRMMod]
FROM [Study] [s] --View
                                     Inner JOIN [ProposalInfo] [p] ON [p].[StudyRowId] = [s].[StudyRowId] 
                                     Inner JOIN [client] [c] ON [c].[clrowid] = [p].[clientrowid]
                                     Inner JOIN [client] [fc] ON [fc].[clrowid] = [p].[FinclientRowId] 
                                     Inner JOIN [std_costcenter] [Sd]ON [Sd].proposalid=p.ProposalRowId
                                     Inner join costcenter [cc] ON [cc].cc=sd.ccid
                                     Inner Join contact [ct] on [ct].corowid=[p].ContactRowId and p.ClientRowId=ct.clrowid
									 Inner join contact [fct] on [fct].corowid = [p].FinContactRowId 
                                   where [p].[ProposalNumber]=@ProposalNumber and [p].[ProposalLetter]=@ProposalLetter 
                                     and [p].[ModificationNumber]=@ModificationNumber";


            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(searchString, connectionString);
            var splitProposal = ProposalNumber.Split('-');
            string proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
            string proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
            string ModificationNumber = splitProposal[1];
            da.SelectCommand.Parameters.AddWithValue("@ProposalNumber", proposalValue);
            da.SelectCommand.Parameters.AddWithValue("@ProposalLetter", proposalLetter);
            da.SelectCommand.Parameters.AddWithValue("@ModificationNumber", ModificationNumber);

            try
            {
                // connection.Open();
                // SqlDataReader reader = command.ExecuteReader();
                da.Fill(ds);
                //while (reader.Read())
                //{
                //    Console.WriteLine("\t{0}\t{1}\t{2}",
                //        reader[0], reader[1], reader[2]);
                //}
                //reader.Close();
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //}
            return ds;
        }

        public DataSet GetProposalDefaultValues()
        {
            string json = string.Empty;
            DataSet ds = new DataSet();
            var query = ProposalQueries.PROPOSAL_ON_LOAD_QUERY;
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            try
            {
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0].ItemArray.Length >= 1 && ds.Tables[0].Rows[0][0].ToString().ToLowerInvariant() == "tablenames")
                {
                    for (int i = 0; i < ds.Tables[0].Rows[0].ItemArray.Length; i++)
                    {
                        ds.Tables[i].TableName = ds.Tables[0].Rows[0][i].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }

        public DataSet GetProposalOnRetrieve(ProposalModel propObj)
        {
            DataSet ds = new DataSet();
            string filterString = string.Empty;
            string proposalValue = string.Empty;
            string proposalLetter = string.Empty;
            string ModificationNumber = string.Empty;


            //            if (!string.IsNullOrEmpty(proposalValue) && !string.IsNullOrEmpty(proposalLetter) &&
            //          !string.IsNullOrEmpty(ModificationNumber) && !string.IsNullOrEmpty(propObj.AltCovanceNo)) filterString =
            //          @" ProposalInfo.ProposalNumber=@proposalNumber AND   ProposalInfo.ProposalLetter = @proposalLetter 
            //             AND ProposalInfo.ModificationNumber = @ModificationNumber AND   ProposalInfo.AlternateId = @propObj.AltCovanceNo";
            //            else
            //         {
            if (!string.IsNullOrEmpty(propObj.ProposalNum) )
            {
                var splitProposal = propObj.ProposalNum.Split('-');
                proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
                proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
                ModificationNumber = splitProposal[1];
                ModificationNumber = ModificationNumber.Replace("_", "");
                filterString += "ProposalInfo.ProposalNumber=@proposalValue ";
                filterString += " AND ProposalInfo.ModificationNumber=@modificationNumber ";
                filterString += " AND ProposalInfo.ProposalLetter=@proposalLetter ";

            }
            //if (!string.IsNullOrEmpty(proposalLetter)) filterString += "AND ProposalInfo.ProposalLetter = @proposalLetter ";

            //if (!string.IsNullOrEmpty(ModificationNumber)) filterString += "AND ProposalInfo.ModificationNumber = @ModificationNumber ";
            if (!string.IsNullOrEmpty(propObj.StudyId)) filterString += "ProposalInfo.StudyRowId =(select StudyRowId from StudyInfo where StudyId=@StudyId)";
            /*if (!string.IsNullOrEmpty(propObj.AltCovanceNo)) filterString += "AND ProposalInfo.AlternateId = @AltCovanceNo ";
            if (!string.IsNullOrEmpty(propObj.ChangeOrderNo)) filterString += "AND ProposalInfo.ChangeOrderNumber = @ChangeOrderNumber ";
            if (!string.IsNullOrEmpty(propObj.IndustryType)) filterString += "AND ProposalInfo.IndustryType = @IndustryType ";
            if (!string.IsNullOrEmpty(propObj.IndustrySubType)) filterString += "AND ProposalInfo.IndustrySubType = @IndustrySubType ";
            if (!string.IsNullOrEmpty(propObj.MarketSegment)) filterString += "AND ProposalInfo.MarketSegment = @MarketSegment ";
            if (!string.IsNullOrEmpty(propObj.Opportunity)) filterString += "AND Opportunity_Lexicon.Value = @Oppurtunity ";
            if (!string.IsNullOrEmpty(propObj.ClientName)) filterString += "AND Client.ClName = @ClientName ";
            if (!string.IsNullOrEmpty(propObj.ClientID)) filterString += "AND Client.ClId = @ClientID ";
            if (!string.IsNullOrEmpty(propObj.FinancialClientName)) filterString += "AND FinClient.ClName = @FinancialClientName ";
            if (!string.IsNullOrEmpty(propObj.CRMod)) filterString += "AND ProposalInfo.CRMMod = @CRMMod ";
            if (!string.IsNullOrEmpty(propObj.FinancialClientID)) filterString += "AND FinClient.ClId = @FinancialClientID ";
            if (!string.IsNullOrEmpty(propObj.FinancialParentID)) filterString += "AND FinClient.ClAltCode = @FinancialParentID ";
            if (!string.IsNullOrEmpty(propObj.ConsultantContact)) filterString += "AND ProposalInfo.ConsultantContact = @ConsultantContact ";
            if (!string.IsNullOrEmpty(propObj.Consultant)) filterString += "AND ProposalInfo.Consultant = @Consultant ";
            if (!string.IsNullOrEmpty(propObj.Title)) filterString += "AND ProposalInfo.Title = @Title ";
        /* studyInfo 
            if (!string.IsNullOrEmpty(propObj.StudyInfo.CompoundName)) filterString += "AND ProposalInfo.CompoundName = @CompoundName ";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.TherapeuticArea)) filterString += "AND TherapeuticArea_Lexicon.Value  = @TherapeuticArea";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.CompoundType)) filterString += "AND ProposalInfo.CompoundType  = @CompoundType";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.CompoundIndication)) filterString += "AND ProposalInfo.CompoundIndication  = @CompoundIndication";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.StudyDirector)) filterString += "AND  ProposalInfo.StudyDirector  = @StudyDirector";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.ProgramManager)) filterString += "AND  ProposalInfo.ProgramManager  = @ProgramManager";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.ClientManager)) filterString += "AND   ProposalInfo.ClientManager  = @ClientManager";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.Toxicologist)) filterString += "AND   ProposalInfo.StudyToxicologist  = @Toxicologist";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.LastModifiedBy)) filterString += "AND   ProposalInfo.LastModifyUser  = @LastModifyUser";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.LastModifiedDate)) filterString += "AND   ProposalInfo.LastModifyDate  = @LastModifyDate";
            if (!string.IsNullOrEmpty(propObj.StudyInfo.Cardiologist)) filterString += "AND    Cardiologist_Employee.Employee_Name  = @Cardiologist";
        /* Contracts 
            if (!string.IsNullOrEmpty(propObj.Contracts.ContractManager)) filterString += "AND     ContractManager_Employee.Employee_Name  = @ContractManager";
            if (!string.IsNullOrEmpty(propObj.Contracts.ContractOwner)) filterString += "AND     Client.ContrctOwner  = @ContrctOwner";
            if (!string.IsNullOrEmpty(propObj.Contracts.ContractValue)) filterString += "AND     ProposalInfo.ContractValue  = @ContractValue";
            if (!string.IsNullOrEmpty(propObj.Contracts.Currency)) filterString += "AND     ProposalInfo.Contract_Currency  = @Currency";
            if (!string.IsNullOrEmpty(propObj.Contracts.TotalContractValue)) filterString += "AND     ProposalInfo.TotalContractValue  = @TotalContractValue";
            if (!string.IsNullOrEmpty(propObj.Contracts.DocumentType)) filterString += "AND     DocumentType.DocumentType  = @DocumentType";
            if (!string.IsNullOrEmpty(propObj.Contracts.FeeType)) filterString += "AND     FeeType.FeeType  = @FeeType";
            if (!string.IsNullOrEmpty(propObj.Contracts.ContractLegalEntity)) filterString += "AND     LegalEntity.LegalEntity  = @LegalEntity";
            if (!string.IsNullOrEmpty(propObj.Contracts.FinancialStatus)) filterString += "AND     ProposalInfo.FinancialStatus  = @FinancialStatus";
            if (!string.IsNullOrEmpty(propObj.Contracts.Rateschedule)) filterString += "AND     RateSchedule.RateSchedule  = @RateSchedule";
            if (!string.IsNullOrEmpty(propObj.Contracts.ContractSentDate)) filterString += "AND     Proposal_Date.ContractSentDate  = @ContractSentDate";
        /* Study Details 
            if (!string.IsNullOrEmpty(propObj.StudyDetails.StudyType)) filterString += "AND     ProposalInfo.StudyType  = @StudyType";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.TestSystem)) filterString += "AND     ProposalInfo.TestSystem  = @TestSystem";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.Strain)) filterString += "AND     ProposalInfo.Strain  = @Strain";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.Route)) filterString += "AND     ProposalInfo.Route  = @Route";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.Duration)) filterString += "AND     ProposalInfo.Duration  = @Duration";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.SourceType)) filterString += "AND     ProposalInfo.SourceType  = @SourceType";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.Recovery)) filterString += "AND     ProposalInfo.Recovery  = @Recovery";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.NumberofSites)) filterString += "AND     ProposalDetail.NumberOfSites  = @NumberOfSites";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.ReportTurnAround)) filterString += "AND     ProposalDetail.ReportTurnAround  = @ReportTurnAround";
            if (!string.IsNullOrEmpty(propObj.StudyDetails.ReportFormat)) filterString += "AND     ProposalDetail.ReportFormat  = @ReportFormat";
        /* Dates 
            if (!string.IsNullOrEmpty(propObj.Dates.Award)) filterString += "AND     ProposalInfo.AwardType  = @AwardType";*/

            //  }
            var retrieveQuery = string.Format(ProposalQueries.PROPOSAL_ON_RETRIEVE_QUERY, filterString);
            SqlDataAdapter da = new SqlDataAdapter(retrieveQuery, connectionString);

            da.SelectCommand.Parameters.AddWithValue("@proposalValue", proposalValue);
            da.SelectCommand.Parameters.AddWithValue("@proposalLetter", proposalLetter);
            da.SelectCommand.Parameters.AddWithValue("@modificationNumber", ModificationNumber);
            da.SelectCommand.Parameters.AddWithValue("@StudyId", propObj.StudyId);
            /* da.SelectCommand.Parameters.AddWithValue("@AltCovanceNo", propObj.AltCovanceNo);
            da.SelectCommand.Parameters.AddWithValue("@ChangeOrderNumber", propObj.ChangeOrderNo);
            da.SelectCommand.Parameters.AddWithValue("@IndustryType", propObj.IndustryType);
            da.SelectCommand.Parameters.AddWithValue("@IndustrySubType", propObj.IndustrySubType);
            da.SelectCommand.Parameters.AddWithValue("@MarketSegment", propObj.MarketSegment);
            da.SelectCommand.Parameters.AddWithValue("@Oppurtunity", propObj.Opportunity);
            da.SelectCommand.Parameters.AddWithValue("@ClientName", propObj.ClientName);
            da.SelectCommand.Parameters.AddWithValue("@ClientID", propObj.ClientID);
            da.SelectCommand.Parameters.AddWithValue("@FinancialClientName", propObj.FinancialClientName);
            da.SelectCommand.Parameters.AddWithValue("@CRMMod", propObj.CRMod);
            da.SelectCommand.Parameters.AddWithValue("@FinancialClientID", propObj.FinancialClientID);
            da.SelectCommand.Parameters.AddWithValue("@FinancialParentID", propObj.FinancialParentID);
            da.SelectCommand.Parameters.AddWithValue("@ConsultantContact", propObj.ConsultantContact);
            da.SelectCommand.Parameters.AddWithValue("@Consultant", propObj.Consultant);
            da.SelectCommand.Parameters.AddWithValue("@Title", propObj.Title);
            /* studyInfo 
            da.SelectCommand.Parameters.AddWithValue("@CompoundName", propObj.StudyInfo.CompoundName);
            da.SelectCommand.Parameters.AddWithValue("@TherapeuticArea", propObj.StudyInfo.TherapeuticArea);
            da.SelectCommand.Parameters.AddWithValue("@CompoundType", propObj.StudyInfo.CompoundType);
            da.SelectCommand.Parameters.AddWithValue("@CompoundIndication", propObj.StudyInfo.CompoundIndication);
            da.SelectCommand.Parameters.AddWithValue("@StudyDirector", propObj.StudyInfo.StudyDirector);
            da.SelectCommand.Parameters.AddWithValue("@ProgramManager", propObj.StudyInfo.ProgramManager);
            da.SelectCommand.Parameters.AddWithValue("@ClientManager", propObj.StudyInfo.ClientManager);
            da.SelectCommand.Parameters.AddWithValue("@Toxicologist", propObj.StudyInfo.Toxicologist);
            da.SelectCommand.Parameters.AddWithValue("@LastModifyUser", propObj.StudyInfo.LastModifiedBy);
            da.SelectCommand.Parameters.AddWithValue("@LastModifyDate", propObj.StudyInfo.LastModifiedDate);
            da.SelectCommand.Parameters.AddWithValue("@Cardiologist", propObj.StudyInfo.Cardiologist);
            /* Contracts
            da.SelectCommand.Parameters.AddWithValue("@ContractManager", propObj.Contracts.ContractManager);
            da.SelectCommand.Parameters.AddWithValue("@ContrctOwner", propObj.Contracts.ContractOwner);
            da.SelectCommand.Parameters.AddWithValue("@ContractValue", propObj.Contracts.ContractValue);
            da.SelectCommand.Parameters.AddWithValue("@Currency", propObj.Contracts.Currency);
            da.SelectCommand.Parameters.AddWithValue("@TotalContractValue", propObj.Contracts.TotalContractValue);
            da.SelectCommand.Parameters.AddWithValue("@DocumentType", propObj.Contracts.DocumentType);
            da.SelectCommand.Parameters.AddWithValue("@FeeType", propObj.Contracts.FeeType);
            da.SelectCommand.Parameters.AddWithValue("@LegalEntity", propObj.Contracts.ContractLegalEntity);
            da.SelectCommand.Parameters.AddWithValue("@FinancialStatus", propObj.Contracts.FinancialStatus);
            da.SelectCommand.Parameters.AddWithValue("@RateSchedule", propObj.Contracts.Rateschedule);
            da.SelectCommand.Parameters.AddWithValue("@ContractSentDate", propObj.Contracts.ContractSentDate);
            /* Study Details 
            da.SelectCommand.Parameters.AddWithValue("@StudyType", propObj.StudyDetails.StudyType);
            da.SelectCommand.Parameters.AddWithValue("@TestSystem", propObj.StudyDetails.TestSystem);
            da.SelectCommand.Parameters.AddWithValue("@Strain", propObj.StudyDetails.Strain);
            da.SelectCommand.Parameters.AddWithValue("@Route", propObj.StudyDetails.Route);
            da.SelectCommand.Parameters.AddWithValue("@Duration", propObj.StudyDetails.Duration);
            da.SelectCommand.Parameters.AddWithValue("@SourceType", propObj.StudyDetails.SourceType);
            da.SelectCommand.Parameters.AddWithValue("@Recovery", propObj.StudyDetails.Recovery);
            da.SelectCommand.Parameters.AddWithValue("@NumberOfSites", propObj.StudyDetails.NumberofSites);
            da.SelectCommand.Parameters.AddWithValue("@ReportTurnAround", propObj.StudyDetails.ReportTurnAround);
            da.SelectCommand.Parameters.AddWithValue("@ReportFormat", propObj.StudyDetails.ReportFormat);
            /* Dates 
            da.SelectCommand.Parameters.AddWithValue("@AwardType", propObj.Dates.Award);*/

            try
            {
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }


        //        public DataSet GetProposalOnRetrieve(string proposalNumber, string proposalLetterValue, string studyId)
        //        {
        //            DataSet ds = new DataSet();
        //            string filterString = string.Empty;
        //            var splitProposal = proposalNumber.Split('-');
        //            string proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
        //            string proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
        //            string ModificationNumber = splitProposal[1];

        //            if (!string.IsNullOrEmpty(proposalNumber) && !string.IsNullOrEmpty(proposalLetter) &&
        //          !string.IsNullOrEmpty(ModificationNumber)) filterString =
        //          @" ProposalInfo.ProposalNumber=@proposalNumber AND   ProposalInfo.ProposalLetter = @proposalLetter 
        //             AND ProposalInfo.ModificationNumber = @ModificationNumber ";
        //            else
        //            {
        //                if (!string.IsNullOrEmpty(proposalNumber)) filterString += "ProposalInfo.ProposalNumber=@proposalNumber ";
        //                if (!string.IsNullOrEmpty(proposalLetter)) filterString += "AND ProposalInfo.ProposalLetter = @proposalLetter ";
        //                if (!string.IsNullOrEmpty(ModificationNumber)) filterString += "AND ProposalInfo.ModificationNumber = @ModificationNumber ";
        //            }
        //            var retrieveQuery = string.Format(ProposalQueries.PROPOSAL_ON_RETRIEVE_QUERY, filterString);
        //            SqlDataAdapter da = new SqlDataAdapter(retrieveQuery, connectionString);

        //            da.SelectCommand.Parameters.AddWithValue("@ProposalNumber", proposalValue);
        //            da.SelectCommand.Parameters.AddWithValue("@ProposalLetter", proposalLetter);
        //            da.SelectCommand.Parameters.AddWithValue("@ModificationNumber", ModificationNumber);

        //            try
        //            {
        //                da.Fill(ds);
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine(ex.Message);
        //            }
        //            return ds;
        //        }

        public DataTable GetPersonalReportNames(string userId)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT report from myrep (NOLOCK) where username = @userId order by report";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@userId", userId);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds.Tables[0];
        }
        public DataTable GetPersonalReportContentsSQL(string reportName, string userId)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT sql  from myrep (NOLOCK) where report = @reportName and username = @userId";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@reportName", reportName);
            da.SelectCommand.Parameters.AddWithValue("@userId", userId);
            try
            {
                da.Fill(ds);
                string sqlQuery = ds.Tables[0].Rows[0]["sql"].ToString();
                return ExecutePersonalReportSQL(sqlQuery);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
        private DataTable ExecutePersonalReportSQL(string sqlQuery)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(sqlQuery, connectionString);
            try
            {
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds.Tables[0];
        }

        public DataTable GetSharedReportNames()
        {
            DataSet ds = new DataSet();
            var query = @"SELECT * from grouprep (NOLOCK) order by report";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            try
            {
                da.Fill(ds);
                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds.Tables[0];
        }

        public DataTable GetSharedReportContents(string reportName)
        {
            DataSet ds = new DataSet();
            var query = @"SELECT sql from grouprep (NOLOCK)  where report = @reportName";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@reportName", reportName);
            try
            {
                da.Fill(ds);
                string sqlQuery = ds.Tables[0].Rows[0]["sql"].ToString();
                return ExecutePersonalReportSQL(sqlQuery);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }



        public DataSet GetProposalForMisc(string proposalNumber)
        {
            string filterString = string.Empty;
            var splitProposal = proposalNumber.Split('-');
            string proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
            string proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
            string ModificationNumber = splitProposal[1];
            ModificationNumber = ModificationNumber.Replace("_", "");
            if (!string.IsNullOrEmpty(proposalValue)) filterString += "ProposalInfo.ProposalNumber=@proposalValue ";
            if (!string.IsNullOrEmpty(proposalLetter)) filterString += "AND ProposalInfo.ProposalLetter = @proposalLetter ";
            if (!string.IsNullOrEmpty(ModificationNumber)) filterString += "AND ProposalInfo.ModificationNumber = @ModificationNumber ";
            string searchString = @"Select
ProposalMisc.Type,
ProposalMisc.SubType,
ProposalMisc.Value,
ProposalMisc.Comments
FROM ProposalMisc(NOLOCK)
LEFT OUTER JOIN ProposalInfo (NOLOCK) 
ON ProposalMisc.ProposalRowId = ProposalInfo.ProposalRowId
WHERE ProposalInfo.ProposalRowId =(select ProposalRowId from ProposalInfo where {0})
";

            var retrieveQuery = string.Format(searchString, filterString);

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(retrieveQuery, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@proposalValue", proposalValue);
            da.SelectCommand.Parameters.AddWithValue("@ProposalLetter", proposalLetter);
            da.SelectCommand.Parameters.AddWithValue("@ModificationNumber", ModificationNumber);


            try
            {

                da.Fill(ds);

                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //}
            return ds;
        }

        public DataSet GetProposalForCost(string proposalNumber)
        {
            string filterString = string.Empty;
            var splitProposal = proposalNumber.Split('-');
            string proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
            string proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
            string ModificationNumber = splitProposal[1];
            ModificationNumber = ModificationNumber.Replace("_", "");
            if (!string.IsNullOrEmpty(proposalValue)) filterString += "ProposalInfo.ProposalNumber=@proposalValue ";
            if (!string.IsNullOrEmpty(proposalLetter)) filterString += "AND ProposalInfo.ProposalLetter = @proposalLetter ";
            if (!string.IsNullOrEmpty(ModificationNumber)) filterString += "AND ProposalInfo.ModificationNumber = @ModificationNumber ";
            string searchString = @"SELECT
costing.coproductline1,
costing.coproductline2,
costing.submitteddate As Sub_Date,
costing.costeddateest AS RE_Est,
costing.costeddate As RE_Act,
costing.resourceestimate As CostWithG_A,
costing.listprice As ListPrice,
costing.costedby As RE_By,
costing.numofoptions As Options,
costing.include As Recost,
costing.comments As Comments,
costing.currency_type As Currency
FROM costing(NOLOCK)
LEFT OUTER JOIN ProposalInfo (NOLOCK) 
ON costing.ProposalId = ProposalInfo.ProposalRowId
WHERE ProposalInfo.ProposalRowId =(select ProposalRowId from ProposalInfo where {0})
";

            var retrieveQuery = string.Format(searchString, filterString);

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(retrieveQuery, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@proposalValue", proposalValue);
            da.SelectCommand.Parameters.AddWithValue("@ProposalLetter", proposalLetter);
            da.SelectCommand.Parameters.AddWithValue("@ModificationNumber", ModificationNumber);


            try
            {

                da.Fill(ds);

                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //}
            return ds;
        }


        public DataSet GetProposalForPricing(string proposalNumber)
        {
            string filterString = string.Empty;
            var splitProposal = proposalNumber.Split('-');
            string proposalValue = Regex.Match(splitProposal[0], @"\d+").Value;
            string proposalLetter = Regex.Match(splitProposal[0], @"[a-zA-Z]+").Value;
            string ModificationNumber = splitProposal[1];
            ModificationNumber = ModificationNumber.Replace("_", "");
            if (!string.IsNullOrEmpty(proposalValue)) filterString += "ProposalInfo.ProposalNumber=@proposalValue ";
            if (!string.IsNullOrEmpty(proposalLetter)) filterString += "AND ProposalInfo.ProposalLetter = @proposalLetter ";
            if (!string.IsNullOrEmpty(ModificationNumber)) filterString += "AND ProposalInfo.ModificationNumber = @ModificationNumber ";
            string searchString = @"SELECT
* FROM pricing(NOLOCK)
LEFT OUTER JOIN ProposalInfo (NOLOCK) 
ON pricing.ProposalId = ProposalInfo.ProposalRowId
WHERE ProposalInfo.ProposalRowId =(select ProposalRowId from ProposalInfo where {0})
";

            var retrieveQuery = string.Format(searchString, filterString);

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(retrieveQuery, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@proposalValue", proposalValue);
            da.SelectCommand.Parameters.AddWithValue("@ProposalLetter", proposalLetter);
            da.SelectCommand.Parameters.AddWithValue("@ModificationNumber", ModificationNumber);


            try
            {

                da.Fill(ds);

                var v = ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //}
            return ds;
        }


    }
}
