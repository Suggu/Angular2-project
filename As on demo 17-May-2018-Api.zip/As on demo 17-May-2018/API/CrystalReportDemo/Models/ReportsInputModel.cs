﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CrystalReportDemo.Models
{
    public class ReportsInputModel
    {
        public ReportsInputModel()
        {
            this.Paramvalues = new Dictionary<string, string>();
        }
        public string ReportName { get; set; }
        public string Name { get; set; }
        public string StudyCode { get; set; }
        public Dictionary<string, string> Paramvalues { get; set; }
        public string[] InputDataType { get; set; }

    }

}