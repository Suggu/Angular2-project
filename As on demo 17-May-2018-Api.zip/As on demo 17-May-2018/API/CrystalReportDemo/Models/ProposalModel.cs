﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;

namespace CrystalReportDemo.Models
{
    public class ProposalModel
    {
        public string ProposalNum { get; set; } 
        public string ProposalLetter { get; set; }
        public string ProposalNumber { get; set; }
        public string ModificationNumber { get; set; }
        public string AlternateId { get; set; }
        public string StudyId { get; set; }
        public string ClientProtocolNo { get; set; }
        public string HistoricalNumber { get; set; }
        public string ChangeOrderNumber { get; set; }
        public string Division { get; set; }
        public string BaseDeptCode { get; set; }
        public string AdditionalDeptCode { get; set; }
        public string SBU { get; set; }
        public string CRMMod { get; set; }
        public string Site { get; set; }
        public string IndustryType { get; set; }
        public string IndustrySubType { get; set; }
        public string MarketSegment { get; set; }
        public string Opportunity { get; set; }
        public string Title { get; set; }
        public string ClientID { get; set; }
        public string ParentID { get; set; }
        public string ClientName { get; set; }
        public string ContactFirstName { get; set; }
        public string ContactLastName { get; set; }
        public string FinParentID { get; set; }
        public string FinContactFirstName { get; set; }
        public string FinContactLastName { get; set; }
        public string ClientContact { get; set; }
        public string FinClientID { get; set; }
        public string FinancialParentID { get; set; }
        public string FinClientName { get; set; }
        public string FinancialClientContact { get; set; }
        public string Consultant { get; set; }
        public string ConsultantContact { get; set; }
        // public ProposalNumber ProposalNum { get; set; }
        public StudyInfoModel StudyInfo { get; set; }
        public StudyDetailsModel StudyDetails { get; set; }
        public DatesModel Dates { get; set; }
        public ContractsModel Contracts { get; set; }
        public MiscModel Misc { get; set; }
        
    }
    /*public class ProposalNumber
    {
        public string ProposalNumber { get; set; }
        public string ProposalLetter { get; set; }
        public string ModificationNumber { get; set; }
    }*/
    public class StudyInfoModel
    {
        public string CompoundName { get; set; }
        public string TherapeuticArea { get; set; }
        public string CompoundType { get; set; }
        public string CompoundIndication { get; set; }
        public string ProductLine1 { get; set; }
        public string ProductLine2 { get; set; }
        public string AccountExecutive { get; set; }
        public string StudyDirector { get; set; }
        public string ProgramManager { get; set; }
        public string ClientManager { get; set; }
        public string Toxicologist { get; set; }
        public string Cardiologist { get; set; }
        public string LastModifyDate { get; set; }
        public string LastModifyUser { get; set; }
    }
    public class StudyDetailsModel
    {
        public string StudyType { get; set; }
        public string Strain { get; set; }
        public string TestSystem { get; set; }
        public string Route { get; set; }
        public string StudyLocation { get; set; }
        public string Duration { get; set; }
        public string Recovery { get; set; }
        public string SourceType { get; set; }
        public string NumberofSubjects { get; set; }
        public string NumberofTissues { get; set; }
        public string NumberOfSites { get; set; }
        public string Source { get; set; }
        public string AuthorizedDate { get; set; }
        public string ReportTurnAround { get; set; }
        public string ReportFormat { get; set; }
        public string ModStatus { get; set; }
        public string ModComments { get; set; }
        public string AnalChem { get; set; }
        public string ClinChem { get; set; }
	    public string ImmunoChem { get; set; }
	    public string MetChem { get; set; }
	    public string BioChem { get; set; }
    }
    public class DatesModel
    {
        public string Award { get; set; }

        public string RejectionReason { get; set; }

        public string InactivateReason { get; set; }
    }
    
    public class ContractsModel
    {
        public string ContractSentDate { get; set; }
        public string ContractSignedDate { get; set; }
        public string Contract_Currency { get; set; }
        public string ContractValue { get; set; }
        public string TotalContractValue { get; set; }
        public string LegalEntity { get; set; }
        public string ContractManager { get; set; }
        public string ContrctOwner { get; set; }
        public string FeeType { get; set; }
        public string DocumentType { get; set; }
        public string RateSchedule { get; set; }
        public string FinancialStatus { get; set; }
        public string RestrictiveComments { get; set; }
        public string InvoicingInstructions { get; set; }
    }
    public class MiscModel
    {
        public string Type { get; set; }

        public string SubType { get; set; }

        public string Value { get; set; }
        public string Comments { get; set; }
        
    }
}