﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;

namespace CrystalReportDemo.Models
{
    //public class ReportsParameterModel
    //{
    //    public ReportsParameterModel()
    //    {
    //        this.properties = new Dictionary<string, ExpandoObject>();
    //        this.required = new List<string>();
    //    }
    //    public string type { get; set; }
    //    public Dictionary<string, ExpandoObject> properties { get; set; }
    //    public List<string> required { get; set; }
    //}


    public class ReportsParameterModel
    {
        public ReportsParameterModel()
        {

            this.templateOptions = new ExpandoObject();
        }
        public string type { get; set; }
        public string key { get; set; }
        public string defaultValue { get; set; }
        public string tooltip { get; set; }
        public ExpandoObject templateOptions { get; set; }
    }

    public class Options
    {
        public string Label { get; set; }
        public string Value { get; set; }
    }

    public class RootDDObject
    {
        public RootDDObject()
        {

            this.options = new List<Options>();
        }
        public List<Options> options { get; set; }
    }
}
