﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CrystalReportDemo.Models
{
    public class UserInfoModel
    {
        public string FullName { get; set; }
        public string Permission { get; set; }

        public List<string> permissionList { get; set; }
        public string UserId { get; set; }
        public bool IsAuthenticated { get; set; }
        public string Token { get; set; }
        public string GroupName { get; set; }
        public DateTime TokenExpiresOn { get; set; }
    }
}