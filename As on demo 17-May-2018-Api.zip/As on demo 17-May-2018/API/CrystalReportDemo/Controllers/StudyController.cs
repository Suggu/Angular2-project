﻿using CrystalReportDemo.Common;
using CrystalReportDemo.Filters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace CrystalReportDemo.Controllers
{
    [GenericAuthorizationFilter(false)]
    public class StudyController : ApiController
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        [HttpGet]
        public object GetStudy(string studyCode)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetStudy(studyCode);
                string JSONString = string.Empty;
                //JObject json=new JObject.Parse();
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                //JSONString = JsonConvert.DeserializeObject(JSONString).ToString();
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
       
        [HttpGet]
        public object GetPersonnelInfo(string studyCode)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetPersonnelInfo(studyCode);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
        
        [HttpGet]
        public object GetPhaseDetails(string studyCode, string phaserowid)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetPhaseDetails(studyCode, phaserowid);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
       
        [HttpGet]
        public object GetDateDetails(string studyCode, string phaserowid)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetDateDetails(studyCode, phaserowid);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        public object GetProposalDetails(string studyCode)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposalDetails(studyCode);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
       
        [HttpGet]
        public object GetAgencyDetails(string studyCode)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetAgencyDetails(studyCode);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
       
        [HttpGet]
        public object GetPhaseValues(string studyCode)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetPhaseValues(studyCode);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
       
        [HttpGet]
        public object GetGuidelinesDetails(string studyCode)
        {
            try { 
            var obj = new Connection();
            var ds = obj.GetGuidelinesDetails(studyCode);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
      
        [HttpGet]
        public object GetStudyNumbers(string studyCode, string clientId, string financialClientId, string title)
        {
            try { 
            var obj = new Connection();
            studyCode = studyCode != null ? studyCode : "";
            clientId = clientId != null ? clientId : "";
            financialClientId = financialClientId != null ? financialClientId : "";
            title = title != null ? title : "";
            var ds = obj.GetStudyNumbers(studyCode, clientId, financialClientId, title);
            string JSONString = string.Empty;
            JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
            object result = JsonConvert.DeserializeObject(JSONString);
            return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        public object GetNewPhaseDropDownValues()
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetNewPhaseDropDownValues();
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

     
    }
}
