﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CrystalReportDemo.Filters;
using CrystalReportDemo.Models;
using CrystalDecisions.CrystalReports.Engine;
using CrystalReportDemo.Common;
using System.Web;
using System.Configuration;
using System.IO;
using NLog;
using CrystalDecisions.Shared;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Dynamic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Runtime.Serialization;
using Newtonsoft.Json;


namespace CrystalReportDemo.Controllers
{

    [GenericAuthorizationFilter(true)]
    public class ReportsController : ApiController
    {

        private static readonly CommonLogger _loggerObj = new CommonLogger();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        [HttpPost]
        /// <summary>
        /// Method to return BLOB object and later can be converted as a Pdf file in UI.
        /// </summary>
        public HttpResponseMessage GetPdfReport(ReportsInputModel inputObj)
        {
            HttpResponseMessage result = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                logger.Info("Calling GetPdfReport method");
                logger.Info("In GetPdfReport method");
                var srReport = new ReportDocument();
                srReport = GenerateSampleReport(inputObj);
                byte[] pdf = ConvertRptToBLOB(srReport, "PDF");
                if (pdf != null)
                {
                    logger.Info("Returning  ByteArrayContent");
                    result.Content = new ByteArrayContent(pdf);
                    return result;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NoContent, "Exception occured");
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return Request.CreateErrorResponse(HttpStatusCode.NoContent, "Exception occured");
        }

        [HttpPost]

        /// <summary>
        /// Method to return BLOB object and later can be converted as a XLS file in UI.
        /// </summary>
        public HttpResponseMessage GetXlsReport(ReportsInputModel inputObj)
        {
            HttpResponseMessage result = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var srReport = new ReportDocument();
                srReport = GenerateSampleReport(inputObj);
                byte[] pdf = ConvertRptToBLOB(srReport, "XLS");
                result.Content = new ByteArrayContent(pdf);
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return result;
        }

        [HttpPost]

        /// <summary>
        /// Method to return BLOB object and later can be converted as a RTF file in UI.
        /// </summary>
        public HttpResponseMessage GetRtfReport(ReportsInputModel inputObj)
        {
            HttpResponseMessage result = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var srReport = new ReportDocument();
                srReport = GenerateSampleReport(inputObj);
                byte[] pdf = ConvertRptToBLOB(srReport, "RTF");
                result.Content = new ByteArrayContent(pdf);

            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return result;
        }

        /// <summary>
        /// Code to generate COA report based on inputs
        /// </summary>

        private ReportDocument GenerateSampleReport(ReportsInputModel inputObj)
        {
            ReportDocument srReport = new ReportDocument(); try
            {
                logger.Info("PL: Clin Path Workload");
                logger.Info("Selected report is PL: Clin Path Workload");
                srReport = LoadReportByName(inputObj.ReportName);
                SetReportParameterValue(inputObj, srReport);
                return srReport;
            }
            catch (Exception ex)
            {

                logger.Trace(ex);
                srReport.Close();
                srReport.Dispose();
            }
            return srReport;
        }
        /* Generic method to dynamically set the report parameter values.*/
        private static void SetReportParameterValue(ReportsInputModel inputObj, ReportDocument srReport)
        {
            // DateTime parsedDateOutput;

            ParameterValues crParameterValues = new ParameterValues();
            int n=-1;
            if (srReport.ParameterFields.Count > 0)
            {    
                foreach (KeyValuePair<string, string> item in inputObj.Paramvalues)
                {
                    n = inputObj.Paramvalues.ToList().IndexOf(item);
                    string typeValue = inputObj.InputDataType[n];
                    if (typeValue.Contains("datepicker"))
                    {
                        srReport.SetParameterValue(item.Key, (String.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(item.Value.Split('T')[0]).AddDays(1))));

                    }
                    else
                    {
                        srReport.SetParameterValue(item.Key, item.Value);
                    }
                }
            }
            //For study level reports
            if (inputObj.Name == "Study")
            {
                //srReport.SetParameterValue(@"DeptCode", "");
                string formula = "{StudyInfo.StudyId} =";
                string queryFormula = String.Format("{0} '{1}' AND", formula, inputObj.StudyCode);
                srReport.RecordSelectionFormula = queryFormula + srReport.RecordSelectionFormula;
            }
        }
        private static void ConvertToCRDateFormat(ReportsInputModel inputObj, out DateTime parsedDateOutput)
        {
            DateTime parsedDate = System.DateTime.Now;
            foreach (KeyValuePair<string, string> item in inputObj.Paramvalues)
            {

                try
                {
                    if (item.Key.ToLower().Contains("date"))
                    {
                        DateTime.TryParseExact(item.Value,
                         "dd-MM-yyyy",
                         CultureInfo.InvariantCulture,
                         DateTimeStyles.None,
                         out parsedDate);
                    }
                }
                catch (Exception ex)
                {
                    logger.Trace(ex);

                }
            }
            parsedDateOutput = parsedDate;
        }

        [HttpGet]
        public List<ReportsParameterModel> GetReportParameters(string reportName)
        {
            logger.Info("Getting the report parameters");
            List<ReportsParameterModel> reportsParameterObjList = new List<ReportsParameterModel>();
            try
            {
                var srReport = LoadReportByName(reportName);

                List<ExpandoObject> expandoObjList = new List<ExpandoObject>();
                if (srReport.ParameterFields.Count > 0)
                {
                    logger.Info("Report parameter count ", srReport.ParameterFields.Count);
                    for (int i = 0; i < srReport.ParameterFields.Count; i++)
                    {
                        //To remove the subreport parameters from UI
                        if (srReport.ParameterFields[i].ReportName == string.Empty)
                        {
                            ReportsParameterModel reportsParameterObj = new ReportsParameterModel();
                            dynamic expando = new ExpandoObject();
                            logger.Info("Assigning the report parameters");
                            reportsParameterObj.key = srReport.ParameterFields[i].ParameterFieldName.ToString();
                            // reportsParameterObj.properties.fields.type = srReport.ParameterFields[i].ParameterValueKind.ToString();
                            expando.type = (srReport.ParameterFields[i].ParameterValueKind.ToString().
                                 Equals("DateParameter") || (srReport.ParameterFields[i].ParameterValueKind.ToString().
                                 Equals("DateTimeParameter"))) ? "datepicker" : "input";
                            reportsParameterObj.type = "input";
                            expando.label = reportsParameterObj.key;
                            reportsParameterObj.defaultValue = "";
                            reportsParameterObj.tooltip = srReport.ParameterFields[i].PromptText.ToString();
                            expando.placeholder = srReport.ParameterFields[i].PromptText.ToString();
                            if (expando.type == "datepicker")
                            {
                                reportsParameterObj.defaultValue = System.DateTime.Now.AddYears(-2).ToShortDateString();
                                reportsParameterObj.type = "datepicker";
                            }
                            else
                            {

                            }
                            //  expando.placeholder = srReport.ParameterFields[i].PromptText;
                            // To get the default values. E.g : to get the dropdown values*/
                            RootDDObject ddObj = new RootDDObject();

                            if (srReport.ParameterFields[i].DefaultValues.Count > 0)
                            {
                                expando.required = true;
                                reportsParameterObj.type = "select";
                                expando.type = "select";
                                expando.labelProp = "Label";
                                expando.valueProp = "Label";
                                // expando.required = "true";
                                List<Options> optionsList = new List<Options>();
                                foreach (ParameterDiscreteValue discreteValue in srReport.ParameterFields[i].DefaultValues)
                                {
                                    Options optionsObj = new Options();
                                    optionsObj.Label = discreteValue.Value.ToString();
                                    optionsObj.Value = discreteValue.Value.ToString();
                                    // ddvalues.Add(discreteValue.Value.ToString());
                                    ddObj.options.Add(optionsObj);
                                    optionsList.Add(optionsObj);

                                }
                                reportsParameterObj.defaultValue = ddObj.options[0].Label;
                                expando.options = optionsList;

                            }
                            reportsParameterObj.templateOptions = expando;
                            reportsParameterObjList.Add(reportsParameterObj);
                        }
                    }
                }
                return reportsParameterObjList;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);

            }
            return null;
        }


        // [HttpGet]
        ///* Generic method to dynamically get the report parameter values from crystal reports.*/
        //public ReportsParameterModel GetReportParameters(string reportName)
        //{
        //    logger.Info("Getting the report parameters");
        //    try
        //    {
        //        ReportsParameterModel reportsParameterObj = new ReportsParameterModel();
        //        var srReport = LoadReportByName(reportName);

        //        if (srReport.ParameterFields.Count > 0)
        //        {
        //            logger.Info("Report parameter count ", srReport.ParameterFields.Count);
        //            Dictionary<string, ExpandoObject> dictObj = new Dictionary<string, ExpandoObject>();
        //            reportsParameterObj.type = "object";
        //            // properties propObj = new properties();
        //            for (int i = 0; i < srReport.ParameterFields.Count; i++)
        //            {
        //                logger.Info("Assigning the report parameters");
        //                dynamic expando = new ExpandoObject();
        //                // To add the required fields
        //                reportsParameterObj.required.Add(srReport.ParameterFields[i].ParameterFieldName.ToString());
        //                //if (srReport.ParameterFields[i].DefaultValues.Count > 0)
        //                //{
        //                //    // To add the required fields
        //                //    reportsParameterObj.required.Add(srReport.ParameterFields[i].ParameterFieldName.ToString());
        //                //}
        //                // UI is accepting "string" as the type for all controls.
        //                expando.type = "string"; // reportsParameterObj.properties.fields.type = srReport.ParameterFields[i].ParameterValueKind.ToString();
        //                expando.format = (srReport.ParameterFields[i].ParameterValueKind.ToString().
        //                     Equals("DateParameter") || (srReport.ParameterFields[i].ParameterValueKind.ToString().
        //                     Equals("DateTimeParameter"))) ? "date" : "string";
        //                // To get the default values. E.g : to get the dropdown values*/
        //                if (srReport.ParameterFields[i].DefaultValues.Count > 0)
        //                {

        //                    List<string> ddvalues = new List<string>();

        //                    foreach (ParameterDiscreteValue discreteValue in srReport.ParameterFields[i].DefaultValues)
        //                    {
        //                        ddvalues.Add(discreteValue.Value.ToString());
        //                        expando.@enum = ddvalues.ToArray();

        //                    }
        //                }

        //                dictObj.Add(srReport.ParameterFields[i].ParameterFieldName, expando);
        //            }
        //            reportsParameterObj.properties = dictObj;
        //        }
        //        return reportsParameterObj;
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.Trace(ex);
        //        logger.Trace(ex);
        //    }
        //    return null;
        //}

        /* Generic method to load the report from the file server based on the report name*/
        private static ReportDocument LoadReportByName(string reportName)
        {
            var srReport = new ReportDocument();
            string reportPath = string.Empty;
            NameValueCollection section = (NameValueCollection)ConfigurationManager.GetSection("Reports");
            try
            {
                //Reports Module
                foreach (var key in section.AllKeys)
                {
                    if (key.Equals(reportName))
                    {
                        reportPath = ConfigurationManager.AppSettings["ReportsPath"].ToString() + section[key];
                        srReport.Load(reportPath);
                    }
                }
                //Study Level Reports && Shared reports
                if (reportPath == string.Empty)
                {
                    NameValueCollection studySection = (NameValueCollection)ConfigurationManager.GetSection("Study");
                    foreach (var key in studySection.AllKeys)
                    {
                        if (key.Equals(reportName))
                        {
                            reportPath = ConfigurationManager.AppSettings["ReportsPath"].ToString() + studySection[key];
                            srReport.Load(reportPath);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return srReport;
        }

        [HttpGet]
        /*Method to get the report names*/
        public string[] GetReportNames(string moduleName)
        {
            var srReport = new ReportDocument();
            string reportPath = string.Empty;
            List<string> reportsList = new List<string>();
            string[] reports;
            NameValueCollection section = null;
            try
            {
                switch (moduleName)
                {
                    case "Reports":
                        section = (NameValueCollection)ConfigurationManager.GetSection("Reports");
                        break;
                    case "Study":
                        section = (NameValueCollection)ConfigurationManager.GetSection("Study");
                        break;
                    default:
                        section = (NameValueCollection)ConfigurationManager.GetSection("Study");
                        break;
                }

                foreach (var key in section.AllKeys)
                {
                    reportsList.Add(key);
                }
                reports = reportsList.ToArray();
                return reports;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        /*Method to get the report names*/
        public string GetReportsDescription(string reportName)
        {
            DataSet ds = new DataSet();
            string rptFileName = string.Empty;
            string connectionString = ConfigurationManager.AppSettings["ConnectionString"];
            var query = @"select [comments] from [formattedreport] where [reportpath]=@RPTFileName";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);

            NameValueCollection section = (NameValueCollection)ConfigurationManager.GetSection("Reports");
            foreach (var key in section.AllKeys)
            {
                if (key.Equals(reportName))
                {
                    rptFileName = section[key].ToString();
                }
            }
            if (rptFileName == string.Empty)
            {
                NameValueCollection studySection = (NameValueCollection)ConfigurationManager.GetSection("Study");
                foreach (var key in studySection.AllKeys)
                {
                    if (key.Equals(reportName))
                    {
                        rptFileName = studySection[key].ToString();
                    }
                }
            }
            da.SelectCommand.Parameters.AddWithValue("@RPTFileName", rptFileName);
            try
            {
                da.Fill(ds);
                if (ds.Tables[0] != null)
                {
                    return ds.Tables[0].Rows[0]["comments"].ToString();
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }


            return null;
        }

        /// <summary>
        /// Set the Database credentials to the report
        /// </summary>
        /// <param name="reportDocument"></param>
        private static void SetDBLogonForReport(ReportDocument reportDocument)
        {
            try
            {
                var connectionInfo = new ConnectionInfo
                {
                    ServerName = ConfigurationManager.AppSettings["DBServerName"],
                    UserID = ConfigurationManager.AppSettings["DBUserName"],
                    Password = ConfigurationManager.AppSettings["DBPassword"],
                    Type = ConnectionInfoType.SQL,
                    DatabaseName = ConfigurationManager.AppSettings["DBName"],
                    IntegratedSecurity = false
                };

                var tables = reportDocument.Database.Tables;
                foreach (Table table in tables)
                {
                    var tableLogonInfo = table.LogOnInfo;
                    tableLogonInfo.ConnectionInfo = connectionInfo;
                    table.ApplyLogOnInfo(tableLogonInfo);
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
        }

        /// <summary>
        /// Method to convert the report directly to a blob in the selected exported format.
        /// </summary>
        /// <param name="frptDoc"></param>
        /// <param name="fOutputFormat"></param>
        /// <returns></returns>
        public  byte[] ConvertRptToBLOB(ReportDocument frptDoc, string fOutputFormat)
        {
            byte[] outputBLOB = null;
            var memoryStream = new MemoryStream();
            logger.Info("In ConvertRptToBLOB method");
            try
            {
                using (frptDoc)
                {

                    SetDBLogonForReport(frptDoc);
                    string title=frptDoc.ReportClientDocument.DisplayName.ToString();
                    frptDoc.SummaryInfo.ReportTitle = title;
                    switch (fOutputFormat.Trim().ToUpper())
                    {
                        case ("PDF"):
                            memoryStream =
                                (MemoryStream)frptDoc.ExportToStream(ExportFormatType.PortableDocFormat);
                            break;

                        case ("XLS"):

                            memoryStream = (MemoryStream)frptDoc.ExportToStream(ExportFormatType.Excel);
                            break;

                        case ("RTF"):

                            memoryStream = (MemoryStream)frptDoc.ExportToStream(ExportFormatType.Text);
                            break;

                        default:
                            throw new Exception("Unsupported Export Format:" + fOutputFormat);
                    }
                    outputBLOB = memoryStream.ToArray();
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            finally
            {
                if (memoryStream != null)
                {
                    memoryStream.Dispose();
                }
            }
            return outputBLOB;
        }
        # region PersonalReports

        [HttpGet]
        /*Method to get the personal report names*/
        public string[] GetPersonalReportNames(string userId)
        {

            List<string> reportsList = new List<string>();
            string[] reports;
            var obj = new Connection();
            try
            {
                DataTable dt = obj.GetPersonalReportNames("melangov");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    reportsList.Add(dt.Rows[i]["report"].ToString());
                }
                reports = reportsList.ToArray();
                return reports;
            }

            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        /*Method to get the personal report contents as Excel*/
        public ExpandoObject GetPersonalReportContents(string reportName, string userId)
        {

            var obj = new Connection();
            try
            {
                List<string> headers = new List<string>();
                dynamic expandoObj = new ExpandoObject();
                DataTable dt = obj.GetPersonalReportContentsSQL(reportName, userId);
                foreach (DataColumn dc in dt.Columns)
                {
                    headers.Add(dc.ColumnName);
                }
                expandoObj.headers = headers;
                expandoObj.contents = dt;
                return expandoObj;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }


        [HttpGet]
        /*Method to get the report description*/
        public string GetPersonalReportsDescription(string reportName, string userId)
        {
            DataSet ds = new DataSet();
            string rptFileName = string.Empty;
            string connectionString = ConfigurationManager.AppSettings["ConnectionString"];
            var query = @"SELECT 'USER DEFINED:'+description as description  from myrep (NOLOCK) where username = @username and report=@reportName ";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@reportName", reportName);
            da.SelectCommand.Parameters.AddWithValue("@username", userId);
            try
            {
                da.Fill(ds);
                if (ds.Tables[0] != null)
                {
                    return ds.Tables[0].Rows[0]["description"].ToString();
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }


            return null;
        }

        # endregion

        # region SharedReports
      
        [HttpGet]
        /*Method to get the shared report names*/
        public List<ExpandoObject> GetSharedReportNames()
        {

            List<ExpandoObject> reportsList = new List<ExpandoObject>();
            var obj = new Connection();
            try
            {
                DataTable dt = obj.GetSharedReportNames();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dynamic expandoObj = new ExpandoObject();
                    expandoObj.report=dt.Rows[i]["report"].ToString();
                    expandoObj.crystalrep = dt.Rows[i]["cryrep"].ToString();
                    reportsList.Add(expandoObj);
                }
                return reportsList;
            }

            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        /*Method to get the report description*/
        public string GetSharedReportsDescription(string reportName)
        {
            DataSet ds = new DataSet();
            string rptFileName = string.Empty;
            string connectionString = ConfigurationManager.AppSettings["ConnectionString"];
            var query = @"SELECT 
       CASE WHEN cryrep ='N' THEN 'USER DEFINED:'+description
           ELSE 'FORMATTED:'+description END AS description
  FROM grouprep (NOLOCK)  where report=@reportName ";
            SqlDataAdapter da = new SqlDataAdapter(query, connectionString);
            da.SelectCommand.Parameters.AddWithValue("@reportName", reportName);
            try
            {
                da.Fill(ds);
                if (ds.Tables[0] != null)
                {
                    return ds.Tables[0].Rows[0]["description"].ToString();
                }
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }


            return null;
        }


        [HttpGet]
        /*Method to get the personal report contents as Excel*/
        public ExpandoObject GetSharedReportContents(string reportName)
        {
            var obj = new Connection();
            try
            {
                List<string> headers = new List<string>();
                dynamic expandoObj = new ExpandoObject();
                DataTable dt = obj.GetSharedReportContents(reportName);
                foreach (DataColumn dc in dt.Columns)
                {
                    headers.Add(dc.ColumnName);
                }
                expandoObj.headers = headers;
                expandoObj.contents = dt;
                return expandoObj;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        #endregion
    }
}
