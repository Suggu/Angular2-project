﻿using CrystalReportDemo.Common;
using CrystalReportDemo.Filters;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using CrystalReportDemo.Models;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CrystalReportDemo.Controllers
{
    [GenericAuthorizationFilter(false)]
    public class ProposalController : ApiController
    {
        private readonly Logger logger = LogManager.GetCurrentClassLogger();

        [HttpGet]
        public object GetProposal(string ProposalNumber)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposal(ProposalNumber);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        public object GetProposalDefaultValues()
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposalDefaultValues();
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }


        [HttpPost]
        public object GetProposalOnRetrieve(ProposalModel propObj)
        {
            try
            {

                //ProposalNumber propNumObj = new ProposalNumber();
                StudyInfoModel studyInfoObj = new StudyInfoModel();
                ContractsModel contractObj = new ContractsModel();
                StudyDetailsModel studyDetailsObj = new StudyDetailsModel();
                DatesModel datesObj = new DatesModel();
                MiscModel miscObj = new MiscModel();
                //propObj.ProposalNum = propNumObj;
                propObj.StudyInfo = studyInfoObj;
                propObj.Contracts = contractObj;
                propObj.StudyDetails = studyDetailsObj;
                propObj.Dates = datesObj;
                propObj.Misc = miscObj;
                var obj = new Connection();
                var ds = obj.GetProposalOnRetrieve(propObj);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }


        [HttpGet]
        public object GetProposalForMisc(string proposalNumber)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposalForMisc(proposalNumber);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        public object GetProposalForCost(string proposalNumber)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposalForCost(proposalNumber);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }

        [HttpGet]
        public object GetProposalForPricing(string proposalNumber)
        {
            try
            {
                var obj = new Connection();
                var ds = obj.GetProposalForPricing(proposalNumber);
                string JSONString = string.Empty;
                JSONString = (ds.Tables.Count != 0) ? JsonConvert.SerializeObject(ds.Tables[0]) : "[]";
                object result = JsonConvert.DeserializeObject(JSONString);
                return result;
            }
            catch (Exception ex)
            {
                logger.Trace(ex);
            }
            return null;
        }
    }
}
