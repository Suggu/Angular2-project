﻿using CrystalReportDemo.Models;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Configuration;
using CrystalReportDemo.Filters;
using CrystalReportDemo.CustomToken;
using System.Threading;
using CrystalReportDemo.Common;
using NLog;

namespace CrystalReportDemo.Controllers
{
    [GenericAuthorizationFilter(false)]
    public class AuthenticationController : ApiController
    {
        private readonly Logger _loggerObj = LogManager.GetCurrentClassLogger();
        private readonly TokenRepository _tokenRepObj = new TokenRepository();
        Random rnd = new Random();
        [HttpGet]
        /// <summary>
        /// Method to check if the logged in windows user is authenticated. (Check is done against dev AD).
        /// </summary>
        public HttpResponseMessage CheckIfUserAuthenticated()
        {

            string userName;
            UserInfoModel user = new UserInfoModel();
            try
            {

                userName = HttpContext.Current.Request.LogonUserIdentity.Name.ToString();
               // string samAccName = userName.Split('\\')[1];
                string samAccName = "ksampath";
                //  SearchResult result;
                // string AD_URL = "LDAP://ENT.covance.com:389";
                // DirectorySearcher searcher1 = new DirectorySearcher(AD_URL);
                // searcher1.Filter = string.Format("(&(objectCategory=person)(objectClass=user)(SAMAccountname={0}))", samAccName);
                // searcher1.PropertiesToLoad.Add("samaccountname");
                // searcher1.PropertiesToLoad.Add("mail");
                // searcher1.PropertiesToLoad.Add("displayname");//full name
                //  searcher1.PropertiesToLoad.Add("givenName");//first anme
                // searcher1.PropertiesToLoad.Add("sn");//last name
                //  searcher1.PropertiesToLoad.Add("lastLogon");//last log on

                // var results = searcher1.FindAll();
                // result = (results.Count != 0) ? results[0] : null;
                // if (result != null)
                // {

                //  Request.Headers.Add("TokenExpiry", ConfigurationManager.AppSettings["AuthTokenExpiry"]);
                // Request.Headers.Add("Access-Control-Expose-Headers", "Token,TokenExpiry");
                user = GetUserInfo(samAccName);
                return Request.CreateResponse(HttpStatusCode.OK, user);
            }
            catch (Exception ex)
            {
                _loggerObj.Trace(ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, user);
            }
            return Request.CreateResponse(HttpStatusCode.InternalServerError, user);

        }

        /// <summary>
        /// Method to generate the token for user.
        /// </summary>
        private UserInfoModel GetUserInfo(string userId)
        {
          
            TokenRepository _repoObj = new TokenRepository();
            try
            {
                return _tokenRepObj.GetUserInfo(userId);
            }
            catch (Exception ex)
            {
                _loggerObj.Trace(ex);
            }
            return null;
        }


    }
}
