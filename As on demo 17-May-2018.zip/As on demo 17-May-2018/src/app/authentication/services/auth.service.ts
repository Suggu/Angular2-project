import { Globals } from './../../shared/globals';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import { User } from './user.service';

const USERS = [
  new User(1, 'sbezawad', 'password', 'ADMIN'),
  new User(2, 'ksampath', 'password', 'ADMIN'),
  new User(1, 'rnayak', 'password', '')
];
const usersObservable = Observable.of(USERS);

@Injectable()
export class AuthService {
  private redirectUrl = '/home/app';
  private loginUrl = '/login';
  private unauthUrl = '/home/app/not-authorized';
  private isloggedIn = false;
  private loggedInUser: User;
  constructor(
    private _globals: Globals
  ) { }

  getAllUsers(): Observable<User[]> {
    return usersObservable;
  }
  isUserAuthenticated(username: string, password: string): Observable<boolean> {
    return this.getAllUsers()
      .map(users => {
        const userInfo = users.find (user => (user.username === username) && (user.password === password));
        if (userInfo) {
          this.isloggedIn = true;
          this.loggedInUser = userInfo;
        } else {
          this.isloggedIn = false;
        }
        return this.isloggedIn;
      });
  }
  isUserLoggedIn(): boolean {
    return this.isloggedIn;
  }
  getRedirectUrl(): string {
    return this.redirectUrl;
  }
  setRedirectUrl(url: string): void {
    this.redirectUrl = url;
  }
  getLoginUrl(): string {
    return this.loginUrl;
  }
  getunauthUrl(): string {
    return this.unauthUrl;
  }
  getLoggedInUser(): User {
    this.getAllUsers()
      .subscribe(users => {
        const userInfo = users.find (user => (user.username === this._globals.userId));
        if (userInfo) {
          this.isloggedIn = true;
          this.loggedInUser = userInfo;
        } else {
          this.isloggedIn = false;
        }
      });
    return this.loggedInUser;
  }
  logoutUser(): void {
    this.isloggedIn = false;
  }
}
