import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';

@Injectable()
export class AuthCookie {
  constructor() { }

  getAuth(): string {
    return Cookie.get('Auth_Cookie');
  }

  setAuth(res: any): void {
    // 0.0138889//this accept day not minuts
    const encodedCookieValue = btoa(JSON.stringify({ 'Name': res.FullName, 'UserId': res.UserId,
     'Token': res.Token, 'Permission': res.permissionList, 'GroupName': res.GroupName }));
    Cookie.set('Auth_Cookie', encodedCookieValue, 0.0416667);
  }

  deleteAuth(): void {
    Cookie.delete('Auth_Cookie');
  }

  getUserNameValue() {
    const decodedCookieValue = this.getAuth();
    const userName = decodedCookieValue !== '' ? JSON.parse(atob(decodedCookieValue)).Name : '';
    return userName;
  }

  getUserIdValue() {
    const decodedCookieValue = this.getAuth();
    const userId = decodedCookieValue !== '' ? JSON.parse(atob(decodedCookieValue)).UserId : null;
    return userId;
  }

  getUserRoleValue() {
    // const decodedCookieValue = this.getAuth();
    const decodedCookieValue = this.getAuth();
    const userGroup = decodedCookieValue !== '' ? JSON.parse(atob(decodedCookieValue)).GroupName : null;
    return userGroup;
  }

  getUserPermissions() {
    // const decodedCookieValue = this.getAuth();
    const decodedCookieValue = this.getAuth();
    const userPermissions = decodedCookieValue !== '' ? JSON.parse(atob(decodedCookieValue)).Permission : null;
    return userPermissions;
  }
}
