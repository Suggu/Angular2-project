import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild {

  constructor(private authService: AuthService, private router: Router) {
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const loggedInUser = this.authService.getLoggedInUser();
    const roles = route.data['roles'] as Array<string>;
    /* Admin */
    if (loggedInUser.role === 'ADMIN') {
      return true; } else if ( roles != null && roles.length === 1) {
       /* Study and reports */
    if (this.authService.isUserLoggedIn() && loggedInUser.role === roles[0]) {
      return true;
    } else {
      this.router.navigate([this.authService.getunauthUrl()]);
    }
    return false;
  }else {
    this.router.navigate([this.authService.getunauthUrl()]);
  }
  }
  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const loggedInUser = this.authService.getLoggedInUser();
    if (loggedInUser.role === 'ADMIN') {
      return true;
    }else {
      this.router.navigate([this.authService.getunauthUrl()]);
    }
  }
}
