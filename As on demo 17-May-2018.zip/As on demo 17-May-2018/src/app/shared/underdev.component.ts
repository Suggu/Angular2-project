import { Component } from '@angular/core';

@Component({
  template: `<section class="content-header">
  <h1>Under Development</h1>
</section>`
})
export class UnderDevComponent {

}
