import { Component } from '@angular/core';

@Component({
  selector: 'app-not-authorized',
  templateUrl: './not-authorized.html'
})
export class NotAuthorisedComponent {

}
