
export class AppConstants {
  public static DD_CLIENT_DETAILS_URL = 'http://localhost:50599/api/Study/GetProposalDetails?studyCode=';
  public static STUDY_DETAILS_URL = 'http://localhost:50599/api/Study/GetStudy?studyCode=';
  public static DD_AGENCY_DETAILS_URL = 'http://localhost:50599/api/Study/GetAgencyDetails?studyCode=';
  public static DD_PHASE_VALUES_URL = 'http://localhost:50599/api/Study/GetPhaseValues?studyCode=';
  public static Phase_URL = 'http://localhost:50599/api/Study/GetPhaseDetails?';
  public static PERSONNEL_URL = 'http://localhost:50599/api/Study/GetPersonnelInfo?';
  public static AGENCY_URL = 'http://localhost:50599/api/Study/GetAgencyDetails?';
  public static GUIDE_LINES_URL = 'http://localhost:50599/api/Study/GetGuidelinesDetails?';
  public static DATE_URL = 'http://localhost:50599/api/Study/GetDateDetails?';
  public static STUDY_NUMBER_URL = 'http://localhost:50599/api/Study/GetStudyNumbers?studyCode=';
  public static PROPOSAL_NUMBER_URL = 'http://localhost:50599/api/proposal/GetProposalOnRetrieve';
}


