
import { CommonModule } from '@angular/common';
import { NotAuthorisedComponent } from './not-authorized.component';
import { NgModule } from '@angular/core';
import { NgxPermissionsModule } from 'ngx-permissions';
import { NgxPermissionsService } from 'ngx-permissions';
import { USE_PERMISSIONS_STORE } from 'ngx-permissions';
import { ValidationDialogComponent } from './validation-dialog/validation-dialog.component';
import { AppMaterialModule } from './app-material.module';
import { FedMaskDirective } from '../maincontent/reportsmodule/date-mask.directive';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { TooltipModule } from 'ngx-tooltip';
import { FloatingActionMenuModule } from 'ng2-floating-action-menu';
import { HighlightDirective } from './highlight.directive';
import { ReportsLoaderComponent } from '../maincontent/reportsmodule/reports-loader/reports-loader.component';
@NgModule({
  declarations: [
    NotAuthorisedComponent,
    ValidationDialogComponent,
    FedMaskDirective,
    HighlightDirective,
    ReportsLoaderComponent
  ],

  imports: [
    CommonModule,
    NgxPermissionsModule.forRoot(),
    AppMaterialModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '14px',
      primaryColour: '#3c8dbc',
      secondaryColour: '#3c8dbc',
      tertiaryColour: '#3c8dbc',
      fullScreenBackdrop: false
    }),
    TooltipModule,
    FloatingActionMenuModule,
  ],

  exports: [
    NotAuthorisedComponent,
    FedMaskDirective,
    LoadingModule,
    TooltipModule,
    FloatingActionMenuModule,
    HighlightDirective,
    NgxPermissionsModule,
  ],
  entryComponents: [ ValidationDialogComponent,ReportsLoaderComponent ],
  providers: []
})

export class SharedModule { }

