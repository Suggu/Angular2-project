import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import 'rxjs/add/observable/throw';
import { AuthCookie } from './../authentication/services/auth-cookie.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Globals } from '../shared/globals';
import {MatSnackBar} from '@angular/material';

@Injectable()
export class CustomHttpInterceptor implements HttpInterceptor {
  constructor(
    private _authCookie: AuthCookie,
    private router: Router,
    public _globals: Globals,
    public snackBar: MatSnackBar
  ) { }
  private redirectUrl = '/home/login';
  token = this._authCookie.getAuth() !== '' ? JSON.parse(atob(this._authCookie.getAuth())).Token : null;
  userId = this._authCookie.getAuth() !== '' ? JSON.parse(atob(this._authCookie.getAuth())).UserId : null;
  token_value: string = this.token;
  userid_value: string = this.userId;

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this._globals.Loader = true;
    const customReq = request.clone({
      setHeaders: {
        // Authorization: `Bearer ${this.auth.getToken()}`
         // 'Authorization': `Bearer ${this.token_value}`,
        // 'UserId': `${this.userid_value}`
        'Authorization': `Bearer ${this.token_value} : ${this.userid_value}`
      }
      // headers: request.headers.set('app-language', 'it')
    });

    return next
      .handle(customReq)
      .do((ev: HttpEvent<any>) => {
        if (ev instanceof HttpResponse) {
          this._globals.Loader = false;
        }
      })
      .catch(error => {
        if (error instanceof HttpErrorResponse) {
          this._globals.Loader = false;
          if (error.status === 401) {
            this.router.navigate([this.redirectUrl]);
          }else if (error.status === 0  || error.status === 403 || error.status === 500) {
            this.snackBar.open('Failed to get response', 'Try after some time', {
              duration: 5000,
            });
            console.log('Failed to process', error);

          }
        }
        return Observable.throw(error);
      });

  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an ErrorObservable with a user-facing error message
    return new ErrorObservable(
      'Something bad happened; please try again later.');
  }
}
