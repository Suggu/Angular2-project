import { AuthCookie } from './../authentication/services/auth-cookie.service';
import { Injectable } from '@angular/core';


@Injectable()

export class Globals {
  constructor( private _authCookie: AuthCookie ) { }
  numOfStudy = 0;
  // have to check '' condition also
  fullname = this._authCookie.getUserNameValue() != null ? this._authCookie.getUserNameValue() : 'Guest';
  Loader= false;
  permission= true;
  role = '';
  editable= true;
  userId = this._authCookie.getUserIdValue();

  userPermissions: any;

  enableChange= false;

  CMS_Study_StudyDetails_Dates= true;
  Study_Study_protocolsign_change= true;
  Study_Study_studyinitiation_change= true;
  Study_Study_studytermination_change= true;
  Study_Study_finalarchive_change= true;
}
