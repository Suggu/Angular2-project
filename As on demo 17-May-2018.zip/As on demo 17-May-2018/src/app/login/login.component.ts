import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../authentication/services/auth.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { LoginLoaderComponent } from './login-loader/login-loader.component';
import { MatDialogModule, MatDialog } from '@angular/material';

@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})

export class LoginComponent implements OnInit {

  formGroup: FormGroup;
  username: string;
  password: string;
  invalidCredentialMsg: string;
// get return url from route parameters or default to '/'
returnUrl = '/home/app';

  ngOnInit() {
    this.formGroup = new FormGroup({
      username: new FormControl('', [
        Validators.required,
        Validators.minLength(8)
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
        // Validators.maxLength(20)
      ])
    });
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    public dialog: MatDialog
  ) {

  }
showLoginLoader(condition: Boolean) {
  if (condition) {
  const dialogRef = this.dialog.open(LoginLoaderComponent, {
     width: '500px',
    // data: { name: 'this.name', animal: 'this.anima'}
  });
  // dialogRef.afterClosed().subscribe(result => {
  //   console.log('The dialog was closed');
  // });
}else {
  this.dialog.closeAll();
}
}
  login() {
    
    this.showLoginLoader(true);
    setTimeout(function() {
      this.authService.isUserAuthenticated(this.username, this.password).subscribe(
        authenticated => {        
          if (authenticated) {
            const url = this.authService.getRedirectUrl();
            setTimeout(() => {
              this.showLoginLoader(false);
              this.router.navigate([url]);
           }, 5000);
            // this.showLoginLoader(false);
            //this.dialog.closeAll();
          } else {
            this.dialog.closeAll();
            this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
          }
        }
      );
    }.bind(this), 500);
  }
}
