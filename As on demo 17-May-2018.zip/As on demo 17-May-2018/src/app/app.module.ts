import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgBootstrapFormValidationModule } from 'ng-bootstrap-form-validation';
import { AppRoutingModule } from './app-routing.module';
import { AppMaterialModule } from './shared/app-material.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { AuthService } from './authentication/services/auth.service';
import { AuthCookie } from './authentication/services/auth-cookie.service';
import { HomeService } from './home.service';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { Globals } from './shared/globals';
import { CustomHttpInterceptor } from './shared/http-interceptor';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home.component';
import { UnderDevComponent } from './shared/underdev.component';
import { DialogComponent } from './dialog/dialog.component';
import { LoginLoaderComponent } from './login/login-loader/login-loader.component';
import { SharedModule } from './shared/shared.module';
import { HintModule , HintService} from 'angular-custom-tour'

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    LoginComponent,
    HomeComponent,
    UnderDevComponent,
    DialogComponent,
    LoginLoaderComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    AppMaterialModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    SharedModule,
    HintModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '14px',
      primaryColour: '#3c8dbc',
      secondaryColour: '#3c8dbc',
      tertiaryColour: '#3c8dbc',
      fullScreenBackdrop: false
    })
  ],
  providers: [ AuthService, AuthGuardService, HomeService, Globals, AuthCookie, HintService,
    { provide: HTTP_INTERCEPTORS, useClass: CustomHttpInterceptor, multi: true }
  ],
  entryComponents: [ DialogComponent, LoginLoaderComponent ],
  bootstrap: [HomeComponent]
})
export class AppModule { }


