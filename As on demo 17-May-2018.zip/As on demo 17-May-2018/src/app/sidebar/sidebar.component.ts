import { Component } from '@angular/core';
import { AppConstants } from '../shared/app-constants';
import { Globals } from '../shared/globals';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.html'
})
export class SidebarComponent {
  numOfStudy: number;
  constructor(private _globals: Globals) {
    this.numOfStudy = _globals.numOfStudy > 0 ? _globals.numOfStudy : 0;
  }
}
