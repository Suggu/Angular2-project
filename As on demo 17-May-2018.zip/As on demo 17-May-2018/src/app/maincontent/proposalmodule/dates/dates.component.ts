import { Dates, Proposal } from './../proposal';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {MatPaginator, MatTableDataSource, MatSort} from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ProposalService } from '../proposal.service';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-dates',
  templateUrl: './dates.component.html',
  styleUrls: ['./dates.component.css']
})
export class DatesComponent implements OnInit,AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  _ref: any;
  DatesForm: FormGroup;
  datesObj:any;
  dates : Proposal[];
  _award;
  status='default';
  _rejectionReason;
  _InactivateReason;
  displayedColumns = ['Date', 'Estimated', 'Actual', 'Comments'];
  datedataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  constructor(private http: HttpClient, private _globals:Globals,
     private _proposalservice: ProposalService) { }

  ngOnInit() {
    //this.getDefaultValues();
    this.DatesForm = new FormGroup({
      _award: new FormControl('', [
      ]),
      _rejectionReason: new FormControl('', [
      ]),
      _InactivateReason: new FormControl('', [
      ]),
    });
  }
    ngAfterViewInit() {
      this.datedataSource.paginator = this.paginator;
      this.datedataSource.sort = this.sort;
    }
    /* getDefaultValues() {
      this._proposalservice.getDefaultValues().subscribe(resDetails => this.setDefaultValues(resDetails));
    }*/
    
    setDatesDetails(proposalDetails){
      this.datesObj=new Proposal();
      this.dates = proposalDetails;
      this.datesObj = proposalDetails[0];
      this.status=this.datesObj.Status;
    }
    loadDatesDetails(proposalDetails, retrieved) {
      if (retrieved) {
        this.setDatesDetails(proposalDetails)
      }
      else {
        this.datesObj=0;
      }

}
}
export interface Element {
  Date: string;
  Estimated: string;
  Actual: string;
  Comments: string;
}

const ELEMENT_DATA: Element[] = [
  {Date: 'Inquiry', Estimated: 'N/A', Actual: ' ', Comments: ' '},
  {Date: 'Initial Response', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Cost', Estimated: 'N/A', Actual: ' ', Comments: ' '},
  {Date: 'Quote', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Outcome', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Follow-Up', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Compound Received', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Protocol Signed', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Study Start', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Study End', Estimated: ' ', Actual: ' ', Comments: ' '}
];

