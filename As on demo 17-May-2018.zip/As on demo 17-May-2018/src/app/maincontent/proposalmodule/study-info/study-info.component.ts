
import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';
import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild, AfterViewInit, Input } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ProposalService } from '../proposal.service';
import { Proposal, StudyInfo } from '../proposal';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-study-info',
  templateUrl: './study-info.component.html',
  styleUrls: ['./study-info.component.css']
})
export class StudyInfoComponent implements AfterViewInit, OnInit {
  _ref: any;
  studyInfoObj: any;
  studyInfo: Proposal[];
  studyInfoForm: FormGroup;
  isDataRetrieved: boolean = false;
  _compoundName;
  _therapeuticArea;
  _compoundType;
  _compoundIndication;
  Product_Line_1;
  Product_Line_2;
  _accountExecutive;
  _studyDirector;
  _programManager;
  _clientManager;
  _toxicologist;
  _cardiologist;
  last_Modified_Date;
  last_Modified_By;
  hidePL2: Boolean = false;
  productDataSourceArr = [];
  @Input('studyId') studyId;
  dummyValues: any = [];
  displayedColumns = ['Product_Line_1', 'Product_Line_2'];
  productDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ngAfterViewInit() {
    this.productDataSource.paginator = this.paginator;
    this.productDataSource.sort = this.sort;
  }
  constructor(private http: HttpClient, private _globals: Globals,
    private _proposalservice: ProposalService) {
  }
  ngOnInit() {

    //this.getDefaultStudyInfo();
    this.studyInfoForm = new FormGroup({
      _compoundName: new FormControl('', [
      ]),
      _therapeuticArea: new FormControl('', [
      ]),
      _compoundType: new FormControl('', [
      ]),
      _compoundIndication: new FormControl('', [
      ]),
      _accountExecutive: new FormControl('', [
      ]),
      _studyDirector: new FormControl('', [
      ]),
      _programManager: new FormControl('', [
      ]),
      _clientManager: new FormControl('', [
      ]),
      _toxicologist: new FormControl('', [
      ]),
      _cardiologist: new FormControl('', [
      ]),
      last_Modified_Date: new FormControl('', [
      ]),
      last_Modified_By: new FormControl('', [
      ]),
      Product_Line_1: new FormControl('', [
      ]),
      Product_Line_2: new FormControl('', [
      ]),
    });
  }
  /* laodConsult() {
    this._consultantContact = [{'Clientcontact': 'dsgasgsfg'}, {'Clientcontact': 'vfdvfdv'}, {'Clientcontact': 'dsgavfffffgsgsfg'}]
    this.hidehintCons = true;
  }
  alertConsult() {
    if (this._consultant === '') {
      const DIALOG_REF = this.dialog.open(ValidationDialogComponent, {
        width: '500px',
        disableClose: true,
        data:  { name: 'Please select a consultant first' },
      });
      // this._clientContact = '';
     // this.dependent = true ;
    }
  } */
  /* getDefaultStudyInfo() {
    this._proposalservice.getDefaultValues().subscribe(resDetails => this.setDefaultValues(resDetails));
  }*/
  setDefaultValues() {
    this.studyInfoObj = 0;
  }
  setStudyInfoDetails(proposalDetails) {
    this.productDataSourceArr.push(proposalDetails[0])
    this.productDataSource = new MatTableDataSource(this.productDataSourceArr);
    this.studyInfoObj = new Proposal();
    this.isDataRetrieved = !this.isDataRetrieved;
    this.studyInfo = proposalDetails;
    this.studyInfoObj = proposalDetails[0];
  }
  loadStudyInfoDetails(proposalDetails, retrieved) {
    if (retrieved) {
      this.setStudyInfoDetails(proposalDetails)
    }
    else {
      this.setDefaultValues();
    }

  }
}
export interface Element {
  Product_Line_1: string;
  Product_Line_2: string;
}

const ELEMENT_DATA: Element[] = [
  { Product_Line_1: 'Mammalian Toxicc', Product_Line_2: '' },
];
