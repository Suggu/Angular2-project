import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ProposalComponent } from './proposal/proposal.component';
import { ProposalModule } from './proposal.module';

export const proposalRoutes: Routes = [
 // { path: 'proposal', component: ProposalComponent },
  { path: '', component: ProposalComponent },
  { path: '**', component: ProposalComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(proposalRoutes)
  ],
  exports: [RouterModule]
})
export class ProposalRoutingModule { }
