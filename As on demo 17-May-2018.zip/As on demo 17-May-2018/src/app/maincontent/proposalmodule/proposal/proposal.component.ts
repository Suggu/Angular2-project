import { Globals } from './../../../shared/globals';
import { PricingComponent } from './../pricing/pricing.component';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver, Input } from '@angular/core';
import { CostingComponent } from './../costing/costing.component';
import { StudyInfoComponent } from './../study-info/study-info.component';
import { DatesComponent } from './../dates/dates.component';
import { StudyDetailsComponent } from './../study-details/study-details.component';
import { ContractsComponent } from './../contracts/contracts.component';
import { MiscComponent } from './../misc/misc.component';
import {ProposalService } from '../proposal.service';
import { Proposal , ProposalOnLoad } from '../proposal';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ValidationDialogComponent } from '../../../shared/validation-dialog/validation-dialog.component';


@Component({
  selector: 'app-proposal',
  templateUrl: './proposal.component.html',
  styleUrls: ['./proposal.component.css']
})
export class ProposalComponent implements OnInit {
  @ViewChild('proposalChild', { read: ViewContainerRef })    container: ViewContainerRef;
  constructor(private _cfr: ComponentFactoryResolver ,
     private _proposalSevice: ProposalService,
      public dialog: MatDialog,
    private _globals:Globals) { }
    _ref:any;   
  components = [];
  isDataRetrieved:Boolean=false;
  active=0;
  proposal: Proposal[];
  propObj = new Proposal();
  proposalForm: FormGroup;
  isexpanded: Boolean= true;
  _panelTitle="Proposal information";
  // Regex for proposal number and studynumber
  proposalNumber_mask = [/[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/,/[0-9]/, /[a-zA-Z]/, '-', /[0-9]/];
  studyNumber_mask =  [/[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, '-', /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/];
  _AltCovanceNo ;
_ProposalNum;
_studyNumber = null;
_clientProtocolNo ;
_historicalNumber ;
_changeOrderNo ;
_div ;
_baseDeptCode;
_AdditionalDeptCode ;
_SBU ;
_CRMod ;
_site ;
_industryType;
_industrySubType;
_marketSegment ;
_opportunity ;
_title;
dependent: Boolean = false;
_clientID;
_parentID;
_clientName = '';
_clientContact ;
_financialClientID;
_financialParentID;
_financialClientName;
_financialClientContact;
_consultant;
_consultantContact;
_ProposalDetails= [];
_ProposalDetailsDD = [];
  ngOnInit() {
   // this.getDefaultValues();
    this.proposalForm = new FormGroup({
      _ProposalNum: new FormControl('', [
      ]),
      _AltCovanceNo: new FormControl('', [
      ]),
      _studyNumber: new FormControl('', [
      ]),
      _clientProtocolNo: new FormControl('', [
      ]),
      _historicalNumber: new FormControl('', [
      ]),
      _changeOrderNo: new FormControl('', [
      ]),
      _div: new FormControl('', [
      ]),
      _baseDeptCode: new FormControl('', [
      ]),
      _AdditionalDeptCode: new FormControl('', [
      ]),
      _SBU: new FormControl('', [
      ]),
      _CRMod: new FormControl('', [
      ]),
      _site: new FormControl('', [
      ]),
      _industryType: new FormControl('', [
      ]),
      _industrySubType: new FormControl('', [
      ]),
      _marketSegment: new FormControl('', [
      ]),
      _opportunity: new FormControl('', [
      ]),
      _title: new FormControl('', [
      ]),
      _clientID: new FormControl('', [
      ]),
      _parentID: new FormControl('', [
      ]),
      _clientName: new FormControl('', [
      ]),
      _clientContact: new FormControl('', [
      ]),
      _financialClientID: new FormControl('', [
      ]),
      _financialParentID: new FormControl('', [
      ]),
      _financialClientName: new FormControl('', [
      ]),
      _financialClientContact: new FormControl('', [
      ]),
      _consultant: new FormControl('', [
      ]),
      _consultantContact: new FormControl('', [
      ]),
   });
  }
  // getDefaultValues() {
  //   this._proposalSevice.getDefaultValues().subscribe(resDetails => this.setDefaultValues(resDetails));
  // }
  setDefaultValues(result) {
  //  this.propOnLoadObj.IndustryType = result[' TB_IndustryType'].IndustryType;
  ///  this.proposalOnLoad=result;
    /*
    this._baseDeptCode = result[' TB_Base_Dept_Code'];
    this._div = result [' TB_Division'];
    this._industryType = result[' TB_IndustryType'];
    // this._industrySubType = result[' TB_IndustryType'];
    this._marketSegment = result[' TB_MarketSegment'];
    this._opportunity = result[' TB_Opportunity'];
    this._site = result[' TB_Site'];
    this._SBU = result[' TB_SBU'];*/
  }
  getProposal() {
    this._proposalSevice.getProposalDetails(this.propObj).
    subscribe(resproposalDetails => this.setProposalDetails(resproposalDetails));
    this.isDataRetrieved=true;
  }
  setProposalDetails(resproposalDetails) {
   this._ProposalDetails = resproposalDetails;
   this.proposal = resproposalDetails;
   // this.propOnLoadObj=resproposalDetails[0];
    this.propObj = resproposalDetails[0];
    this.propObj.FinancialClientContact=this.propObj.FinContactLastName+","+this.propObj.FinContactFirstName;
    this.propObj.ClientContact=this.propObj.ContactLastName+","+this.propObj.ContactFirstName;
    this.propObj.ProposalNum = this.propObj.ProposalNumber+this.propObj.ProposalLetter+"-"+this.propObj.ModificationNumber;    
    this._panelTitle=this._panelTitle + " "+":"+" "+   this.propObj.ProposalNum ;
  }
  onReset() {
    this.proposalForm.reset();
    this.propObj.ProposalNum = '';
    this.propObj.StudyId = '';
    this.active=0;
    this.container.clear();
    this._panelTitle="Proposal information";
  }
  studyInfoClick() {
    this.active=1;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(StudyInfoComponent);
    const studyInfoCmp = this.container.createComponent(comp);
    this.components.push(studyInfoCmp);
    studyInfoCmp.instance._ref = studyInfoCmp;
    studyInfoCmp.instance.loadStudyInfoDetails(this._ProposalDetails,this.isDataRetrieved);
  }
  costingClick() {
    this.active=2;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(CostingComponent);
    const costingCmp = this.container.createComponent(comp);
    this.components.push(costingCmp );
    costingCmp.instance._ref = costingCmp;
    costingCmp.instance.getCostingDetails(this.propObj.ProposalNum);
  }
  pricingClick() {
    this.active=3;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(PricingComponent);
    const PricingCom = this.container.createComponent(comp);
    this.components.push(PricingCom );
    PricingCom.instance._ref = PricingCom;
    PricingCom.instance.getPricingDetails(this.propObj.ProposalNum);
  }
  datesClick() {
    this.active=4;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(DatesComponent);
    const datesCmp = this.container.createComponent(comp);
    this.components.push(datesCmp );
    datesCmp.instance._ref = datesCmp;
    datesCmp.instance.loadDatesDetails(this._ProposalDetails,this.isDataRetrieved);
  }
  studyDetailsClick() {
    this.active=5;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(StudyDetailsComponent);
    const studyDetailsCmp = this.container.createComponent(comp);
    this.components.push(studyDetailsCmp );
    studyDetailsCmp.instance._ref = studyDetailsCmp;
    studyDetailsCmp.instance.loadStudyDDetails(this._ProposalDetails,this.isDataRetrieved);
  }
  contractsClick() {
    this.active=6;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(ContractsComponent);
    const contractsCmp = this.container.createComponent(comp);
    this.components.push(contractsCmp );
    contractsCmp.instance._ref = contractsCmp;
    contractsCmp.instance.loadContractsDetails(this._ProposalDetails,this.isDataRetrieved);
  }
  miscClick() {
    this.active=7;
    this.isexpanded = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(MiscComponent);
    const miscCmp = this.container.createComponent(comp);
    this.components.push(miscCmp );
    miscCmp.instance._ref = miscCmp;
    miscCmp.instance.getMiscDetails(this.propObj.ProposalNum);
  }
}
