import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {MatPaginator,
  MatTableDataSource,
  MatSort} from '@angular/material';
  import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
  import {ProposalService } from '../proposal.service';
  import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-costing',
  templateUrl: './costing.component.html',
  styleUrls: ['./costing.component.css']
})
export class CostingComponent {
_ref: any;
constructor(private _proposalSevice: ProposalService,private _globals:Globals) { }
  displayedColumns = ['No','Product_Line_1', 'Product_Line_2', 'Sub_Date', 'RE_Date(Est)','RE_Date(Act)', 'Cost_with_GndA',
  'List_Price', 'RE_By', 'Options', 'Recost', 'Comments'];
  costdataSource;
  costdataSourcelength=-1;
  public costingLoader=false;

  @ViewChild(MatPaginator) CostingPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
    
  getCostingDetails(proposalNumber){
      this.costingLoader = true;
      this._proposalSevice.getCosingDetails(proposalNumber).
    subscribe(resCostingDetails => {this.costingLoader = false;this.setCostingDetails(resCostingDetails)});
    }
    setCostingDetails(resCostingDetails){
      this.costdataSource =  new MatTableDataSource(resCostingDetails);
      this.costdataSource.paginator = this.CostingPaginator;
      this.costdataSource.sort = this.sort;
      this.costdataSourcelength = this.costdataSource.data.length;
  
    }
    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
      this.costdataSource.filter = filterValue;
    }
    onReset() {
      this.costdataSource = null;
      this.costdataSourcelength = 0;
    }

}

