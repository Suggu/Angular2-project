import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl} from '@angular/forms';
import { ProposalService } from '../proposal.service';
import { Proposal } from '../proposal';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-study-details',
  templateUrl: './study-details.component.html',
  styleUrls: ['./study-details.component.css']
})
export class StudyDetailsComponent implements OnInit {
_ref: any;
StudyDetailsForm: FormGroup;
studyDetails : Proposal[];
studyDetailsObj :any;
isDataRetrieved:Boolean = false;
_studyType;
_testSystem;
_strain;
_route;
_studyLocationDD;
_studyLocation;
_duration;
_recovery;
_sourceType;
_numberofSubjects;
_numberofTissues;
_numberofSites;
_source;
_authorizedDate;
_reportTurnAround;
_reportFormat;
_modStatus;
_modComments;

  constructor(private _proposalservice: ProposalService,private _globals:Globals) { }

  ngOnInit() {
  //  this.getStudyDetailsValues();
    this.StudyDetailsForm = new FormGroup({
      _studyType: new FormControl('', [
      ]),
      _testSystem: new FormControl('', [
      ]),
      _strain: new FormControl('', [
      ]),
      _route: new FormControl('', [
      ]),
      _studyLocationDD: new FormControl('', [
      ]),
      _studyLocation: new FormControl('', [
      ]),
      _duration: new FormControl('', [
      ]),
      _recovery: new FormControl('', [
      ]),
      _sourceType: new FormControl('', [
      ]),
      _numberofSubjects: new FormControl('', [
      ]),
      _numberofTissues: new FormControl('', [
      ]),
      _numberofSites: new FormControl('', [
      ]),
      _source: new FormControl('', [
      ]),
      _authorizedDate: new FormControl('', [
      ]),
      _reportTurnAround: new FormControl('', [
      ]),
      _reportFormat: new FormControl('', [
      ]),
      _modStatus: new FormControl('', [
      ]),
      _modComments: new FormControl('', [
      ]),
    });
  }
  // getStudyDetailsValues() {
  //   this._proposalservice.getDefaultValues().subscribe(resDetails => this.setStudyDetailsValues(resDetails));
  // }
  setStudyDetailsDefaultValues() {
    this.studyDetailsObj=0;
  }
  setStudyDDetails(proposalDetails){
    this.studyDetailsObj=new Proposal();
    this.isDataRetrieved = !this.isDataRetrieved ;
    this.studyDetails = proposalDetails
    this.studyDetailsObj = proposalDetails[0];

  }
  loadStudyDDetails(proposalDetails,retrieved){
    if(retrieved){
    this.setStudyDDetails(proposalDetails)}
    else{
    this.setStudyDetailsDefaultValues();}
    
  }
}
