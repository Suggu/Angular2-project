import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {MatPaginator, MatTableDataSource, MatSort} from '@angular/material';
import {ProposalService } from '../proposal.service';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css']
})
export class PricingComponent {
  _ref: any;
  constructor(private _proposalSevice: ProposalService,private _globals:Globals) { }
  displayedColumns = ['No','Date', 'Gross_Price', 'Discount', 'Net_Price', 'Margin', 'Cost', 'Award',
  'Fixed_Price', 'Marginf', 'Var_Price', 'Marginv', 'Type', 'Comments', 'Currency'];
  pricingDataSource;
  pricingDataSourceLength=-1;
  public pricingLoader=false;

  @ViewChild(MatPaginator) CostingPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
    
  getPricingDetails(proposalNumber){
      this.pricingLoader = true;
      this._proposalSevice.getPricingDetails(proposalNumber).
    subscribe(resPricingDetails => {this.pricingLoader = false;this.setPricingDetails(resPricingDetails)});
    }
    setPricingDetails(resPricingDetails){
      this.pricingDataSource =  new MatTableDataSource(resPricingDetails);
      this.pricingDataSource.paginator = this.CostingPaginator;
      this.pricingDataSource.sort = this.sort;
      this.pricingDataSourceLength = this.pricingDataSource.data.length;
  
    }
    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
      this.pricingDataSource.filter = filterValue;
    }
    onReset() {
      this.pricingDataSource = null;
      this.pricingDataSourceLength = 0;
    }
    
}

