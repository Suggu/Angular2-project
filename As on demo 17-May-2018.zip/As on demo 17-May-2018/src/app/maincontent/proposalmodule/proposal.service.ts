import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders  } from '@angular/common/http';
import { RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../.././shared/app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Proposal } from './proposal';

@Injectable()
export class ProposalService {
  
  constructor(private http: HttpClient) { }
  getProposalDetails(propObj) {
    const url = AppConstants.PROPOSAL_NUMBER_URL;
    const headers = new Headers({
    });
    const options = new RequestOptions({ headers: headers });
    return this.http.post( url, propObj).map((res: Response) => res);
    
    // const url = AppConstants.PROPOSAL_NUMBER_URL + proposalNumber;
    // return this.http.post(url,body,options).map((res: Response) => res );
    //  .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
  }
  
getMiscDetails(proposalNumber) {
  
  return this.http.get('http://localhost:50599/api/proposal/GetProposalForMisc?proposalNumber='+proposalNumber).map((response: Response) => response);
   // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
}
getCosingDetails(proposalNumber) {
  
  return this.http.get('http://localhost:50599/api/proposal/GetProposalForCost?proposalNumber='+proposalNumber).map((response: Response) => response);
   // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
}
getPricingDetails(proposalNumber) {
  
  return this.http.get('http://localhost:50599/api/proposal/GetProposalForPricing?proposalNumber='+proposalNumber).map((response: Response) => response);
   // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
}
}
