import { Component, OnInit, ViewChild } from '@angular/core';
import {MatPaginator, MatTableDataSource, MatSort} from '@angular/material';
import { Proposal } from '../proposal';
import {ProposalService } from '../proposal.service';
import { FormGroup, FormControl} from '@angular/forms';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-misc',
  templateUrl: './misc.component.html',
  styleUrls: ['./misc.component.css']
})
export class MiscComponent implements OnInit {
  constructor(private _proposalSevice: ProposalService,private _globals:Globals) { }
  _ref: any;
  propNum;
  misc : Proposal[];
  miscForm: FormGroup;
  miscObj = new Proposal();
  miscform : Boolean = false;
  miscgrid : Boolean = true;
  displayedColumns = ['Type', 'SubType', 'Value', 'Comments','Delete'];
  miscDataSource;
  miscdataSourceLength=-1;
  public miscLoader = true;
  ngOnInit() {
  this.miscForm = new FormGroup({
    _value: new FormControl('', [
    ]),
    _comments: new FormControl('', [
    ]),
    _type: new FormControl('', [
    ]),
    _subType: new FormControl('', [
    ]), 
  });
}
  @ViewChild(MatPaginator) miscPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
    
    getMiscDetails(proposalNumber){
      this.miscLoader = true;
      this._proposalSevice.getMiscDetails(proposalNumber).
    subscribe(resMiscDetails => {this.miscLoader = false;this.setMiscDetails(resMiscDetails)});
    }
    setMiscDetails(resMiscDetails){ 
      this.miscform=true;
      this.miscgrid=false;
      this.miscDataSource =  new MatTableDataSource(resMiscDetails);
      
      this.miscDataSource.paginator = this.miscPaginator;
      this.miscDataSource.sort = this.sort;
      this.miscdataSourceLength = this.miscDataSource.data.length;
  
    }
    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
      this.miscDataSource.filter = filterValue;
    }
    onReset() {
      this.miscform=false;
      this.miscgrid=true;
      this.miscDataSource = null;
      this.miscdataSourceLength = 0;
    }
    
}
/* export interface Element {
  Date: string;
  Estimated: string;
  Actual: string;
  Comments: string;
}

const ELEMENT_DATA: Element[] = [
  {Date: 'Inquiry', Estimated: 'N/A', Actual: ' ', Comments: ' '},
  {Date: 'Initial Response', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Cost', Estimated: 'N/A', Actual: ' ', Comments: ' '},
  {Date: 'Quote', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Outcome', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Follow-Up', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Compound Received', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Protocol Signed', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Study Start', Estimated: ' ', Actual: ' ', Comments: ' '},
  {Date: 'Study End', Estimated: ' ', Actual: ' ', Comments: ' '}
]; */

