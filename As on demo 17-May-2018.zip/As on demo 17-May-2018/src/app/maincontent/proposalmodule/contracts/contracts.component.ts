import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl} from '@angular/forms';
import { ProposalService } from '../proposal.service';
import { HttpClient } from '@angular/common/http';
import {  Response } from '@angular/http';
import { Proposal } from '../proposal';
import { Globals } from './../../../shared/globals';

@Component({
  selector: 'app-contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.css']
})
export class ContractsComponent implements OnInit {
  _ref: any;
  contractsForm: FormGroup;
  contracts : Proposal[];
  ContractsObj:any;
  _contractsentDate;
  _contractReceivedDate;
  _currency;
  _contractValue;
  _totalContractValue;
  _contractLegalEntity;
  _contractManager;
  _contractOwner;
  _feeType;
  _documentType;
  _rateschedule;
  _financialStatus;
  _restrictiveContractiveComments;
  _invoicingInstructions;


  constructor(private http: HttpClient, private _globals:Globals,
    private _proposalservice: ProposalService) { }

  ngOnInit() {
   // this.getContractDefaultValues();
    this.contractsForm = new FormGroup({
      _contractsentDate: new FormControl('', [
      ]),
      _contractReceivedDate: new FormControl('', [
      ]),
      _currency: new FormControl('', [
      ]),
      _contractValue: new FormControl('', [
      ]),
      _totalContractValue: new FormControl('', [
      ]),
      contractsentDate: new FormControl('', [
      ]),
      _contractLegalEntity: new FormControl('', [
      ]),
      _contractManager: new FormControl('', [
      ]),
      _contractOwner: new FormControl('', [
      ]),
      _feeType: new FormControl('', [
      ]),
      _documentType: new FormControl('', [
      ]),
      _rateschedule: new FormControl('', [
      ]),
      _financialStatus: new FormControl('', [
      ]),
      _restrictiveContractiveComments: new FormControl('', [
      ]),
      _invoicingInstructions: new FormControl('', [
      ]),
    });
  }
  // getContractDefaultValues() {
  //   this._proposalservice.getDefaultValues().subscribe(resDetails => this.setContractDefaultValues(resDetails));
  // }
  setContractDefaultValues() {
    this.ContractsObj=0;
  }
  setContractsDetails(proposalDetails){
    this.ContractsObj = new Proposal();
    this.contracts = proposalDetails;
    this.ContractsObj = proposalDetails[0]; 

  }
  loadContractsDetails(proposalDetails, retrieved) {
    if (retrieved) {
      this.setContractsDetails(proposalDetails)
    }
    else {
      this.setContractDefaultValues();
    }

  }
  onClear() {
    this.contractsForm.reset();
    }

}
