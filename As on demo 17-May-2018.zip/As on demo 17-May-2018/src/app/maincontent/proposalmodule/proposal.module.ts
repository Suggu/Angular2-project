import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TextMaskModule } from 'angular2-text-mask';
import { AppMaterialModule } from '../../shared/app-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProposalComponent } from './proposal/proposal.component';
import { ProposalService } from './proposal.service';
import { ProposalRoutingModule } from './proposal-routing.module';
import { StudyInfoComponent } from './study-info/study-info.component';
import { CostingComponent } from './costing/costing.component';
import { PricingComponent } from './pricing/pricing.component';
import { DatesComponent } from './dates/dates.component';
import { StudyDetailsComponent } from './study-details/study-details.component';
import { ContractsComponent } from './contracts/contracts.component';
import { MiscComponent } from './misc/misc.component';
import { LoadingModule } from 'ngx-loading';
import { TooltipModule } from 'ngx-tooltip';

@NgModule({
  imports: [
    CommonModule,
    AppMaterialModule,
    ReactiveFormsModule,
    FormsModule,
    TextMaskModule,
    ProposalRoutingModule,
    LoadingModule,
    TooltipModule
  ],
  declarations: [ProposalComponent, StudyInfoComponent, CostingComponent, PricingComponent,
     DatesComponent, StudyDetailsComponent, ContractsComponent, MiscComponent],
  providers: [ProposalService],
  entryComponents: [StudyInfoComponent, CostingComponent, PricingComponent, DatesComponent,
    StudyDetailsComponent, MiscComponent, ContractsComponent]
})
export class ProposalModule { }
