import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { ReportsService } from './../reports-service';
import { Component, ViewChild, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/router/src/config';
import { MatDialogModule, MatDialog, DateAdapter } from '@angular/material';
import { DialogComponent } from '../../../dialog/dialog.component';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FloatingActionButton } from 'ng2-floating-action-menu';
import { Globals } from './../../../shared/globals';
import { FormGroup, Form } from '@angular/forms';
import { ReportsLoaderComponent } from './../reports-loader/reports-loader.component';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';
import { setTimeout } from 'timers';

@Component({
  selector: 'formatted-report',
  templateUrl: 'formatted-report.component.html'
})

export class FormattedReportComponent implements OnInit {
  constructor(
    private _service: ReportsService,
    private _router: Router,
    public dialog: MatDialog,
    private dateAdapter: DateAdapter<Date>,
    private _globals: Globals
  ) {
    this.config = {
      placment: 'br',
      effect: 'mfb-zoomin',
      label: 'View Reports',
      iconClass: 'fa fa-newspaper-o  faa-tada animated',
      activeIconClass: 'fa fa-newspaper-o  faa-tada animated',
      toggle: 'click',
      buttons: this.buttons
    }
  }
  _selectedReportDesc = 'Report Description';
  reportInputParameters: any;
  reports;
  _selectedFormattedDDValue;
  filterValues = [];
  config;
  public loader=false;
  public loading=false;
  buttons: Array<FloatingActionButton> = [
    {
      iconClass: 'fa fa-download',
      label: 'Download PDF',
      onClick: () => {
        this.downloadPDF();
      },
    },
    {
      iconClass: 'fa fa-file-excel-o',
      label: 'Download XLS',
      onClick: () => {
        this.downloadXLS();
      },
    },
    {
      iconClass: 'fa fa-file-pdf-o',
      label: 'View PDF',
      onClick: () => {
        this.showPDFInBrowserWindow();
      },
    },

  ];
  placements = [
    {
      value: 'br',
      key: 'bottom right'
    },
    {
      value: 'bl',
      key: 'bottom left'
    },
    {
      value: 'tr',
      key: 'top right'
    },
    {
      value: 'tl',
      key: 'top left'
    },
  ];
  effects = [
    {
      value: 'mfb-zoomin',
      key: 'Zoom In'
    },
    {
      value: 'mfb-slidein',
      key: 'Slide In + Fade'
    },
    {
      value: 'mfb-fountain',
      key: 'Fountain'
    },
    {
      value: 'mfb-slidein-spring',
      key: 'Slide In (Spring)'
    }
  ];
  toggles = [
    'click',
    'hover'
  ];
  dynamicReportParameters;
  userFields: FormlyFieldConfig[];
  reportsInputModel: any = {};
  form = new FormGroup({});

  _isReportsinputHidden: Boolean = true;
  _isViewReportsBtnHidden: Boolean = true;

  ngOnInit() {
    this.loader=true;
    this._service.getReports('Reports').subscribe(
      (res) => {
        this.loader=false;
        this.reports = res;
      }
    );
    
  }
  
  getInputObject() {
    for (var i = 0; i < this.reportInputParameters.length; i++) {
      this.filterValues.push(this.reportInputParameters[i].type)

    }
    const reportsInputParamsValue = {
      'ReportName': this._selectedFormattedDDValue,
      'Paramvalues': this.reportsInputModel,
      'InputDataType': this.filterValues
    };
    return reportsInputParamsValue;
  }


  getSelectedReportDescription(reportName) {
    this._service.getSelectedReportDescription(reportName).subscribe(
      (res) => {
        this._selectedReportDesc = res ? res : this._selectedFormattedDDValue;
      }
    );
  }
  downloadPDF() {
    this.loader=false;
    this.filterValues = [];
    this.showReportsLoader(true);
    this._service.downloadPDF(this.getInputObject()).subscribe(
      (res) => {
        const fileURL = window.URL.createObjectURL(res);
        var a = document.createElement("a");
        document.body.appendChild(a);
        a.href = fileURL;
        a.download = this._selectedFormattedDDValue + "_" + new Date().toLocaleDateString();
        a.target = '_blank';
        a.click();
        this.showReportsLoader(false);
      }
    );
  }
  showPDFInBrowserWindow() {
    this.loader=false;
    this.filterValues = [];
    this.showReportsLoader(true);
    this._service.downloadPDF(this.getInputObject()).subscribe(
      (res) => {
        let fileURL = window.URL.createObjectURL(res);
        fileURL = fileURL + "#" + this._selectedFormattedDDValue;
        var win = window.open(fileURL);        
        this.showReportsLoader(false);
      }
    );
  }

  downloadXLS() {
    this.loader=false;
    this.filterValues = [];
    this.showReportsLoader(true);
    this._service.downloadXLS(this.getInputObject()).subscribe(
      (res) => {
        this.showReportsLoader(false);
        const fileURL = window.URL.createObjectURL(res);
        var a = document.createElement("a");
        document.body.appendChild(a);
        a.href = fileURL;
        a.download = this._selectedFormattedDDValue + "_" + new Date().toLocaleDateString();
        a.target = '_blank';
        a.click();
        this.showReportsLoader(false);
      });
  }

  showRTFInBrowserWindow() {
    this.filterValues = [];
    this.showReportsLoader(true);
    this._service.downloadRTF(this.getInputObject()).subscribe(
      (res) => {
        this.showReportsLoader(false);
        const fileURL = window.URL.createObjectURL(res);
        window.open(fileURL);
      });
  }
  showReportsLoader(condition: Boolean) {
    if (condition) {
      const dialogRef = this.dialog.open(ReportsLoaderComponent, {
        width: '500px'
      });
    } else {
      this.dialog.closeAll();
    }
  }
  // On change event of report type dropdown
  onFormattedReportSelect() {
    this.loader=true;
    this.filterValues = [];
    this._isReportsinputHidden = false;
    this.getSelectedReportDescription(this._selectedFormattedDDValue);
    this.getReportParameterValues(this._selectedFormattedDDValue);
    this.reportsInputModel = {};
    this.loader=false;
  }

  getReportParameterValues(reportName) {
    this.loading=true;
    this._service.getReportParameterValues(reportName).subscribe(resParameterValues => {        
      this.loading=false;
      this.setReportParameterValues(resParameterValues);
      });
    
  }

  setReportParameterValues(resParameterValues) {
    this.reportInputParameters = resParameterValues;
    this.userFields = this.reportInputParameters;
    this._isViewReportsBtnHidden = false;
  }

}



