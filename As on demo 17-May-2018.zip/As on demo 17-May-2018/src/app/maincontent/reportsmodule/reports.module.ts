import { SharedReportComponent } from './shared-reports/shared-report.component';


import { TextMaskModule } from 'angular2-text-mask';
import { AppDateAdapter } from './dateadapter';
import { DatepickerTypeComponent } from './datepicker-type.component';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { ReportsRoutingModule } from './reports-routing.module';
import { RouterModule } from '@angular/router';
import { AppMaterialModule } from '../../shared/app-material.module';
import { SharedModule } from './../../shared/shared.module'; 

import { ReportsComponent } from './reports.component';
import { NotAuthorisedComponent } from '../../shared/not-authorized.component';
import { ReportsService } from './reports-service';
import { JsonSchemaFormModule, MaterialDesignFrameworkModule } from 'angular2-json-schema-form';
import {FormlyModule} from '@ngx-formly/core';
import {FormlyMaterialModule} from '@ngx-formly/material';
import { PersonalReportComponent } from './personal-reports/personal-report.component';
import { FormattedReportComponent } from './formatted-reports/formatted-report.component';
import { LoadingModule } from 'ngx-loading';


@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule,
    AppMaterialModule,
    FormsModule,
    SharedModule,
    TextMaskModule,
    FormlyModule.forRoot({
      types: [{
        name: 'datepicker',
        component: DatepickerTypeComponent,
        wrappers: ['form-field'],
        defaultOptions: {
          defaultValue: new Date().toLocaleDateString(),
          templateOptions: {
            datepickerOptions: {},
          },
        },
      }]
    }),
    FormlyMaterialModule,
    ReactiveFormsModule,
    LoadingModule 
  ],
  declarations: [ ReportsComponent,  DatepickerTypeComponent,
    SharedReportComponent,PersonalReportComponent,FormattedReportComponent],

  providers: [ReportsService,
    {
        provide: DateAdapter, useClass: AppDateAdapter
    }
],
entryComponents: [ SharedReportComponent,PersonalReportComponent,FormattedReportComponent ]
})
export class ReportsModule { }
