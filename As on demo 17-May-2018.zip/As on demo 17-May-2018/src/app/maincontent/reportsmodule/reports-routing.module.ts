
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsComponent } from './reports.component';
import { NotAuthorisedComponent } from '../../shared/not-authorized.component';
import { ReportsModule } from './reports.module';

export const reportRoutes: Routes = [
  { path: 'report', component: ReportsComponent },
  { path: '', component: ReportsComponent },
  { path: '**', component: ReportsComponent },
  { path: 'not-authorized', component: NotAuthorisedComponent }
];

@NgModule({
  imports: [RouterModule.forChild(reportRoutes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
