import { FormattedReportComponent } from './formatted-reports/formatted-report.component';
import { Component, OnInit,  ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { SharedReportComponent } from './shared-reports/shared-report.component';
import { PersonalReportComponent } from './personal-reports/personal-report.component';
import { Globals } from '../././../shared/globals';

@Component({
  selector: 'app-report',
  templateUrl: 'reports.html',
  styleUrls: ['reports.css']
})

export class ReportsComponent implements OnInit {
  reportsInputObj: any = null;
 active = 0;
  
 childReports;

 @ViewChild('childReports', { read: ViewContainerRef }) 
  container: ViewContainerRef;
 
  isPersonalReportsSelected: Boolean = false;
  isSharedReportsSelected: Boolean = false;
  isFormattedReportsSelected: Boolean = false;
 
  ngOnInit() {
    this.active=3;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(FormattedReportComponent);
    this.childReports = this.container.createComponent(comp);
  }

  constructor(
    private _cfr: ComponentFactoryResolver,
    private _globals:Globals
  ) {
   
  }
  
  onPersonalReportsClick() {
    this.active=1; 
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(PersonalReportComponent);
    this.childReports = this.container.createComponent(comp);  
  }
  
  onSharedReportsClick() {
    this.active=2;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(SharedReportComponent);
    this.childReports = this.container.createComponent(comp);
   
  }
  onFormattedReportsClick() {
    this.active=3;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(FormattedReportComponent);
    this.childReports = this.container.createComponent(comp);
  }
}




