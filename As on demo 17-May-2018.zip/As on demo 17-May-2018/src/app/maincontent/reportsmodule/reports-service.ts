import { CustomHttpInterceptor } from './../../shared/http-interceptor';
import { AppConstants } from './../../shared/app-constants';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ReportsService {
  constructor(private http: HttpClient) { }


  private redirectUrl = '/home/app/choose-report';
  private reportUrl = '/home/app/report-parameter';

  downloadPDF(reportsInputObj): any {
    const headers = new Headers({
    });
    const options = new RequestOptions({ headers: headers });
    // Ensure you set the responseType to Blob.
    // options.responseType = ResponseContentType.Blob;
    return this.http.post('http://localhost:50599/api/reports/GetPdfReport'
      , reportsInputObj, { responseType: 'blob' as 'blob' }).map(
        (res) => {
          const fileBlob = res;
          const blob = new Blob([fileBlob], {
            type: 'application/pdf' // must match the Accept type
          });
          return blob;
        });
  }
  downloadXLS(reportsInputObj): any {
    const headers = new Headers({
    });
    const options = new RequestOptions({ headers: headers });
    // Ensure you set the responseType to Blob.
    // options.responseType = ResponseContentType.Blob;
    return this.http.post('http://localhost:50599/api/reports/GetXlsReport', reportsInputObj, { responseType: 'blob' as 'blob' }).map(
      (res) => {
        const fileBlob = res;
        const blob = new Blob([fileBlob], {
          type: 'application/vnd.ms-excel' // must match the Accept type
        });
        return blob;
      });
  }

  downloadRTF(reportsInputObj): any {
    const headers = new Headers({
    });
    const options = new RequestOptions({ headers: headers });
    // Ensure you set the responseType to Blob.
    // options.responseType = ResponseContentType.Blob;
    return this.http.post('http://localhost:50599/api/reports/GetRtfReport', reportsInputObj, { responseType: 'blob' as 'blob' }).map(
      (res) => {
        const fileBlob = res;
        const blob = new Blob([fileBlob], {
          type: 'text/html' // must match the Accept type
        });
        return blob;
      });
  }

  getRedirectUrl(): string {

    return this.redirectUrl;
  }
  setRedirectUrl(url: string): void {
    this.redirectUrl = url;
  }

  getReportUrl(): string {

    return this.reportUrl;
  }
  setReportUrl(url: string): void {
    this.reportUrl = url;
  }

  getReportParameterValues(reportName) {
    return this.http.get('http://localhost:50599/api/reports/GetReportParameters?reportName=' + reportName)
      .map((response: Response) => response);
  }
  getReports(moduleName) {
    return this.http.get('http://localhost:50599/api/reports/GetReportNames?moduleName=' + moduleName)
      .map((response: Response) => response);
  }
  getSelectedReportDescription(reportName) {
    return this.http.get('http://localhost:50599/api/reports/GetReportsDescription?reportName=' + reportName)
      .map((response: Response) => response);
  }
  getPersonalReports() {
    let userId = "sss";
    return this.http.get('http://localhost:50599/api/reports/GetPersonalReportNames?UserId=' + userId)
      .map((response: Response) => response);
  }
  downloadPersonalReport(selectedPersonalReportName) {
    let userId = "melangov";
    return this.http.get('http://localhost:50599/api/reports/GetPersonalReportContents?reportName='+selectedPersonalReportName+
      '&userId='+userId).map(
        (res) => {         
          return res;
        })
  }
  GetPersonalReportsDescription(selectedPersonalReportName) {
    let userId = "melangov";
    return this.http.get('http://localhost:50599/api/reports/GetPersonalReportsDescription?reportName='+selectedPersonalReportName+
      '&userId='+userId).map(
        (res) => {         
          return res;
        })
  }


  getSharedReports() {
    let userId = "melangov";
    return this.http.get('http://localhost:50599/api/reports/GetSharedReportNames')
      .map((response: Response) => response);
  }
  downloadSelectedSharedReport(selectedPersonalReportName) {
    let userId = "melangov";
    return this.http.get('http://localhost:50599/api/reports/GetPersonalReportContents?reportName='+selectedPersonalReportName+
      '&userId='+userId).map(
        (res) => {         
          return res;
        })
  }
  getSelectedSharedReportDescription(selectedSharedReportName) {
    return this.http.get('http://localhost:50599/api/reports/GetSharedReportsDescription?reportName='+selectedSharedReportName
      ).map(
        (res) => {         
          return res;
        })
  }
  downloadSharedReport(selectedSharedReportName) {
    return this.http.get('http://localhost:50599/api/reports/GetSharedReportContents?reportName='
    +selectedSharedReportName).map(
        (res) => {         
          return res;
        })
  }
  

}
