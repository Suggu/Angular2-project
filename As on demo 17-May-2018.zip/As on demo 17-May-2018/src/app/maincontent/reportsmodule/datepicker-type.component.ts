import { Component, ViewChild } from '@angular/core';
import { FieldType } from '@ngx-formly/material';
import { MatInput } from '@angular/material';
import { FormlyTemplateOptions } from '@ngx-formly/core/src/components/formly.field.config';
import { FedMaskDirective } from './date-mask.directive';

@Component({
  selector: 'app-fed-datepicker-field',
  template: `
  <input matInput [matDatepicker]="dp3" readonly tooltip="Please select the date using the calendar icon."
   [(ngModel)]="startDate" [formControl]="formControl">
  <ng-template #matSuffix>
  <mat-datepicker-toggle matSuffix [for]="dp3"></mat-datepicker-toggle>
  </ng-template>
  <mat-datepicker #dp3 disabled="false"></mat-datepicker>`
})
export class DatepickerTypeComponent extends FieldType {
  @ViewChild(MatInput) formFieldControl: MatInput;
  to: FormlyTemplateOptions & { datepickerOptions: any; minDate: Date; maxDate: Date };
  startDate = new Date('January 1, 2016');
  maxdate= new Date();
  maskConfig = {
    mask: [
      new RegExp('\\d'),
      new RegExp('\\d'),
      '/',
      new RegExp('\\d'),
      new RegExp('\\d'),
      '/',
      new RegExp('\\d'),
      new RegExp('\\d'),
      new RegExp('\\d'),
      new RegExp('\\d')
    ],
    showMask: false,
    guide: true,
    placeholderChar: '_'
  };}
  


