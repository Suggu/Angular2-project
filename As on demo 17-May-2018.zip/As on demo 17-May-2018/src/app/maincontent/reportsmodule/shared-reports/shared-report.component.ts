import { FormlyFieldConfig } from '@ngx-formly/core';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { ReportsService } from './../reports-service';
import { Component, ViewChild, OnInit } from '@angular/core';
import { LoadingModule } from 'ngx-loading';
import { MatDialogModule, MatDialog, DateAdapter } from '@angular/material';
import { ReportsLoaderComponent } from './../reports-loader/reports-loader.component';
import { FormGroup } from '@angular/forms';
import { FloatingActionButton } from 'ng2-floating-action-menu';
import { Globals } from '../../././../shared/globals';

@Component({
  selector: 'shared-report',
  templateUrl: 'shared-report.component.html'
})

export class SharedReportComponent implements OnInit  {
  constructor(
    private _service: ReportsService,
    public dialog: MatDialog,
    private _globals:Globals
  ){
    this.config = {
      placment: 'br',
      effect: 'mfb-zoomin',
      label: 'View Reports',
      iconClass: 'fa fa-newspaper-o  faa-tada animated',
      activeIconClass: 'fa fa-newspaper-o  faa-tada animated',
      toggle: 'click',
      buttons: this.buttons
    }
  }
  public loader=false;
  config;
  filterValues = [];
  buttons: Array<FloatingActionButton> = [
    {
      iconClass: 'fa fa-download',
      label: 'Download PDF',
      onClick: () => {
      this.downloadXLS();
     },
    },
    {
      iconClass: 'fa fa-file-excel-o',
      label: 'Download XLS',
      onClick: () => {
      this.downloadXLS();
     },
    },
    {
      iconClass: 'fa fa-file-pdf-o',
      label: 'View PDF',
      onClick: () => {
     this.showPDFInBrowserWindow();
     },
    },
    
  ];
  placements = [
    {
      value: 'br',
      key: 'bottom right'
    },
    {
      value: 'bl',
      key: 'bottom left'
    },
    {
      value: 'tr',
      key: 'top right'
    },
    {
      value: 'tl',
      key: 'top left'
    },
  ];
  effects = [
    {
      value: 'mfb-zoomin',
      key: 'Zoom In'
    },
    {
      value: 'mfb-slidein',
      key: 'Slide In + Fade'
    },
    {
      value: 'mfb-fountain',
      key: 'Fountain'
    },
    {
      value: 'mfb-slidein-spring',
      key: 'Slide In (Spring)'
    }
  ];
  toggles = [
    'click',
    'hover'
  ];
  sharedReports;
  _selectedSharedReportDesc ;
  _selectedSharedDDValue;

  dynamicReportParameters;
  userFields: FormlyFieldConfig[];
  reportsInputModel: any = {};
  form = new FormGroup({});
  
  _isReportsinputHidden: Boolean = true;
  _isViewReportsBtnHidden: Boolean = true;
  reportInputParameters: any;

  ngOnInit(){
    this._selectedSharedReportDesc = 'Report Description';
    this._service.getSharedReports().subscribe(
      (res) => {
        this.sharedReports = res;
      }
    );
      
  }
  
downloadSelectedSharedReport(report){
  this.filterValues = [];
  this._selectedSharedDDValue=report.report;
  this.getSelectedSharedReportDescription(this._selectedSharedDDValue);
  this.showReportsLoader(true);
  // To show the rpt file
  if(report.crystalrep == 'Y'){
    this._isReportsinputHidden=false;
    this.getReportParameterValues(this._selectedSharedDDValue);
    this.reportsInputModel = {};
  }
  // To download as .xlsx file
  else{
    this._isReportsinputHidden=true;
    this._isViewReportsBtnHidden=true;
  this._service.downloadSharedReport(this._selectedSharedDDValue).subscribe(
    (res) => {      
      var options = { 
        fieldSeparator: ',',
        headers: res["headers"]
      };
      new Angular5Csv(res["contents"], this._selectedSharedDDValue ,options);
    
    });
  }
  this.showReportsLoader(false);   
}

getReportParameterValues(reportName) {
  this.loader=true;
    var self=this;
    setTimeout(function(){ 
      self._service.getReportParameterValues(reportName).subscribe(resParameterValues => {
        self.loader=false;
        self.setReportParameterValues(resParameterValues);
  });
},5000);
}

setReportParameterValues(resParameterValues) {    
  this.reportInputParameters = resParameterValues;
  this.userFields = this.reportInputParameters;
  this._isViewReportsBtnHidden = false;
}

getSelectedSharedReportDescription(reportName) {
  this._service.getSelectedSharedReportDescription(reportName).subscribe(
    (res) => {
      if(res !=null){
      this._selectedSharedReportDesc =  res;
      }
    }
  );
}
showReportsLoader(condition: Boolean) {
  if (condition) {
    const dialogRef = this.dialog.open(ReportsLoaderComponent, {
      width: '500px'
    });
  } else {
    this.dialog.closeAll();
  }
}
downloadPDF() {
  this.filterValues = [];
  this.showReportsLoader(true);
  this._globals.Loader = false;
  this._service.downloadPDF(this.getInputObject()).subscribe(
    (res) => {
      this._globals.Loader = false;
      const fileURL = window.URL.createObjectURL(res);
      var a = document.createElement("a");
      document.body.appendChild(a);
      a.href = fileURL;
      a.download = this._selectedSharedDDValue + "_"+new Date().toLocaleDateString();
      a.target = '_blank';
      a.click();
      this.showReportsLoader(false);
    }
  );
}
showPDFInBrowserWindow() {
  this.filterValues = [];
  this.showReportsLoader(true);
  this._globals.Loader = false;
  this._service.downloadPDF(this.getInputObject()).subscribe(
    (res) => {
      let fileURL = window.URL.createObjectURL(res);
      fileURL = fileURL + "#" + this._selectedSharedDDValue;
      var win = window.open(fileURL);
      win.document.title = this._selectedSharedDDValue;
      this.showReportsLoader(false);
    }
  );
}
downloadXLS() {
  this.filterValues = [];
  this.showReportsLoader(true);
  this._service.downloadXLS(this.getInputObject()).subscribe(
    (res) => {
      this.showReportsLoader(false);
      const fileURL = window.URL.createObjectURL(res);
      var a = document.createElement("a");
      document.body.appendChild(a);
      a.href = fileURL;
      a.download = this._selectedSharedDDValue + "_"+new Date().toLocaleDateString();
      a.target = '_blank';
      a.click();
      this.showReportsLoader(false);
    });
}
getInputObject() {
  for (var i = 0; i < this.reportInputParameters.length; i++) {
    this.filterValues.push(this.reportInputParameters[i].type)
  
  }
  const reportsInputParamsValue = {
    'ReportName': this._selectedSharedDDValue,
    'Paramvalues': this.reportsInputModel,
    'InputDataType':this.filterValues
  };
  return reportsInputParamsValue;
}
  }
  


