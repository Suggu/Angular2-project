import { Directive, ElementRef, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import * as textMask from '../../../../node_modules/vanilla-text-mask/dist/vanillaTextMask.js';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: `[fedMask]`
})
export class FedMaskDirective implements OnInit, OnDestroy {
  @HostBinding('class.fed-mask') compClass = true;

  @Input()
  fedMask = {
    mask: [],
    showMask: false,
    guide: true,
    placeholderChar: '_'
  };

  maskedInputController;

  constructor(private element: ElementRef) {}

  ngOnInit(): void {
    this.maskedInputController = textMask.maskInput({
      inputElement: this.element.nativeElement,
      ...this.fedMask
    });
  }

  ngOnDestroy() {
    this.maskedInputController.destroy();
  }
}
