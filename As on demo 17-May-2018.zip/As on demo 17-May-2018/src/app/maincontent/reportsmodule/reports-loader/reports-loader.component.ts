import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-reports-loader',
  templateUrl: 'reports-loader.html'
})
export class ReportsLoaderComponent {

  constructor(
    public dialogRef: MatDialogRef<ReportsLoaderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
