import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { ReportsService } from './../reports-service';
import { Component, ViewChild, OnInit } from '@angular/core';
import { MatDialogModule, MatDialog, DateAdapter } from '@angular/material';
import { ReportsLoaderComponent } from './../reports-loader/reports-loader.component';
import { Globals } from '../../././../shared/globals';

@Component({
  selector: 'personal-report',
  templateUrl: 'personal-report.component.html'
})

export class PersonalReportComponent implements OnInit  {
  constructor(
    private _service: ReportsService,
    public dialog: MatDialog,
    public _globals:Globals
  ){}

  personalReports;
  _selectedPersonalReportDesc ;
  _selectedPersonalDDValue;

  ngOnInit(){
    this._selectedPersonalReportDesc ='Report Description';
      this._service.getPersonalReports().subscribe(
      (res) => {
        this.personalReports = res;
      }
    );
  }
  downloadSelectedPersonalReport(){
    this.getSelectedPersonalReportDescription();
    this.showReportsLoader(true);
    this._service.downloadPersonalReport(this._selectedPersonalDDValue).subscribe(
      (res) => {      
        var options = { 
          fieldSeparator: ',',
          headers: res["headers"]
        };
        new Angular5Csv(res["contents"], this._selectedPersonalDDValue ,options);
      });
      this.showReportsLoader(false);
  }
  getSelectedPersonalReportDescription() {
    this._service.GetPersonalReportsDescription(this._selectedPersonalDDValue).subscribe(
      (res) => {
        if(res !=null){
        this._selectedPersonalReportDesc =  res;
        }
      }
    );
  }
  showReportsLoader(condition: Boolean) {
    if (condition) {
      const dialogRef = this.dialog.open(ReportsLoaderComponent, {
        width: '500px'
      });
    } else {
      this.dialog.closeAll();
    }
  }
  }
  


