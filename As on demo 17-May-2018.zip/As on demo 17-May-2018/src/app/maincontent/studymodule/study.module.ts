import { AddPhaseDialogComponent } from './add-phase-dialog/add-phase-dialog';

import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppMaterialModule } from '../../shared/app-material.module';
import { AppRoutingModule } from '../../app-routing.module';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { StudyRoutingModule } from './study-routing.module';
import { SharedModule } from './../../shared/shared.module';
import { FormlyModule } from '@ngx-formly/core';
import { FormlyMaterialModule } from '@ngx-formly/material';
import { TextMaskModule } from 'angular2-text-mask';

import { StudyComponent } from './study/study.component';
import { StudyDetailComponent } from '../../maincontent/studymodule/study-details/study-detail.component';
import { AgencyGuideComponent } from '../../maincontent/studymodule/agency-guide/agency-guide.component';
import { PhaseComponent } from '../../maincontent/studymodule/phase/phase.component';
import { DatesComponent } from '../../maincontent/studymodule/dates/dates.component';
import { PersonnelComponent } from '../../maincontent/studymodule/personnel/personnel.component';
import { DatepickerTypeComponent } from './study-dialog/datepicker-type.component';
import { AppComponent } from '../../app.component';
import { UnderDevComponent } from '../../shared/underdev.component';
import { StudyDialogComponent } from './study-dialog/study-dialog.component';

import { ReportsService } from './../reportsmodule/reports-service';
import { StudyService } from '../../maincontent/studymodule/study/study.service';
import { PhaseService } from '../studymodule/phase/phase.service';
import { PersonnelService } from '../../maincontent/studymodule/personnel/personnel.service';
import { AgencyGuideService } from './agency-guide/agency-guide.service';
import { DatesService } from './dates/dates.service';
import { StudyDialogService } from './study-dialog/study-dialog.service';

@NgModule({
  declarations: [
    StudyDetailComponent,
    AgencyGuideComponent,
    PhaseComponent,
    DatesComponent,
    PersonnelComponent,
    StudyComponent,
    StudyDialogComponent,
    DatepickerTypeComponent,
    AddPhaseDialogComponent
  ],
  imports: [
    CommonModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    AppMaterialModule,
    StudyRoutingModule,
    SharedModule,
    TextMaskModule,
    FormlyModule,
    FormlyMaterialModule
  ],
  entryComponents: [
     StudyDialogComponent,
     AddPhaseDialogComponent,
      StudyDetailComponent,
    AgencyGuideComponent,
    PhaseComponent,
    DatesComponent,
    PersonnelComponent
   ],
  providers: [ StudyService, PhaseService, PersonnelService,
     AgencyGuideService, DatesService, ReportsService, StudyDialogService]
})
export class StudyModule { }


