import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../../../shared/app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class StudyService {
  constructor(private http: HttpClient) { }
  getClient(studyNumber) {
    const url = AppConstants.DD_CLIENT_DETAILS_URL + studyNumber;
    return this.http.get(url)
      .map((response: Response) => response.json());
      // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
  }
  getStudyNumbers(studyNumber, clientId, financialClientId, title) {
    
    const url = AppConstants.STUDY_NUMBER_URL + studyNumber + '&clientid=' + clientId +
    '&financialclientid=' + financialClientId + '&title=' + title;
    return this.http.get(url).map((res: Response) => res );
    //  .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
  }
  getStudyDetails(studyNumber) {
    const url = AppConstants.STUDY_DETAILS_URL + studyNumber + '&clientId=';
    return this.http.get(url).map((response: Response) => response);
     // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
  }
  getAgencyDetails(studyNumber) {
    const url = AppConstants.STUDY_DETAILS_URL + studyNumber;
    return this.http.get(url).map((response: Response) => response);
  }
  getPhaseValues(studyNumber) {
    return this.http.get(AppConstants.DD_PHASE_VALUES_URL + studyNumber)
     .map((response: Response) => response);
  }

  GetNewPhaseDropDownValues() {
    return this.http.get('http://localhost:50599/api/Study/GetNewPhaseDropDownValues')
    .map((response: Response) => response);
  }
  errorHandler(responseError: Response) {
    console.log(responseError);
    Observable.throw(responseError != null ? responseError : 'Server Error');
  }
}
