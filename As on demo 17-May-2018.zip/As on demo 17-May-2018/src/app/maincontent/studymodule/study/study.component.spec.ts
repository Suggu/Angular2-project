describe('StudyComponent', () => {
  it('True should be true', () => {
    expect(true).toBe(true);
  });
});
