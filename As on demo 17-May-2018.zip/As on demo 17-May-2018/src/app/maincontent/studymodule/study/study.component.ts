import { PersonnelComponent } from './../personnel/personnel.component';
import { DatesComponent } from './../dates/dates.component';
import { PhaseComponent } from './../phase/phase.component';
import { AgencyGuideComponent } from './../agency-guide/agency-guide.component';
import { StudyDetailComponent } from './../study-details/study-detail.component';
import { AddPhaseDialogComponent } from './../add-phase-dialog/add-phase-dialog';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Output, ViewChild, EventEmitter,
   Directive, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import { StudyService } from './study.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Globals } from '../../../shared/globals';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { StudyDialogComponent } from '../study-dialog/study-dialog.component';
import { ValidationDialogComponent } from '../../../shared/validation-dialog/validation-dialog.component';
import { FloatingActionButton } from 'ng2-floating-action-menu';


@Component({
  selector: 'app-study',
  templateUrl: './study.html',
  styleUrls: ['study.css']
})

export class StudyComponent implements OnInit {

  // To display the grid
  displayedColumns = ['Study Code','Financial Client','Title','Client Id'];
  studyDataSource;
  study: any = [];
  studyDataSourceLength = 0;
  @ViewChild(MatPaginator) studyPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  childComponents: any = [];
  isHoussein = false;
  isMultipleStudy= true;

  @ViewChild('studyChild', { read: ViewContainerRef })    container: ViewContainerRef;

   // To call the childern's method on studynumber click
   @Output()
   emitEvent = new EventEmitter();
  // constiable declaration
  phaseDDValue;
  _studyNum = '';
  _CompoundId = '';
  _AssayMod = '';
  _title = '';
  _clientId = '';
  _clientName = '';
  _financialId = '';
  clientDetails = [];
  studyDetails: any = [];
  studyDetailsDD = [];
  phaseValuesDD = [];
  studyNumberDD = [];
  studyNumberValue;
  butDisabled = false;
  disableRetrieve = false;
  prevLength;
  nextLength;
  enableStudyDetailsDate = true;
  enableChangebtn = true;
  studyNumAfterRefine;
  isStudyFetched= true;
  isStudySearched= false;
  studyVal: FormGroup;
  active;
  // Regex for studynumber
  mask = [/[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, '-', /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/];
 
  isStudyPanelExpanded: Boolean = true;

  selectedValue: any; // To store the value phase or data click based on the selection

  /* To Add New Phase   */
 newPhaseDDValues = [];
 config;
 _isMenuBtnHidden = true;
 buttons: Array<FloatingActionButton> = [
   {
     iconClass: 'fa fa-file-pdf-o',
     label: 'Generate Report',
     onClick: () => {
       this.generateReport();
    }
   },
   {
     iconClass: 'fa fa-plus',
     label: 'Add New Phase',
     onClick: () => {
       this.onNewPhaseClick();
    }
  },
    {
      iconClass: 'fa fa-pencil-square-o',
      label: 'Edit',
      onClick: () => {
        this.onEdit();
     }
    }
 ];
 placements = [
   {
     value: 'br',
     key: 'bottom right'
   },
   {
     value: 'bl',
     key: 'bottom left'
   },
   {
     value: 'tr',
     key: 'top right'
   },
   {
     value: 'tl',
     key: 'top left'
   },
 ];
 effects = [
   {
     value: 'mfb-zoomin',
     key: 'Zoom In'
   },
   {
     value: 'mfb-slidein',
     key: 'Slide In + Fade'
   },
   {
     value: 'mfb-fountain',
     key: 'Fountain'
   },
   {
     value: 'mfb-slidein-spring',
     key: 'Slide In (Spring)'
   }
 ];
 toggles = [
   'click',
   'hover'
 ];
studyDetailCmp;
  constructor(
    private _studySevice: StudyService,
     public dialog: MatDialog,
    public _globals: Globals,
    private _cfr: ComponentFactoryResolver
  ) {
    this.config = {
      placment: 'br',
      effect: 'mfb-zoomin',
      label: 'Actions',
      iconClass: 'fa fa-tasks  faa-tada animated',
      activeIconClass: 'fa fa-tasks  faa-tada animated',
      toggle: 'click',
      buttons: this.buttons
    };
   }
  studyDetailsClick() {
    this.active=1;
     this.isStudyPanelExpanded  = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(StudyDetailComponent);
    this.studyDetailCmp = this.container.createComponent(comp);
    this.childComponents.push(this.studyDetailCmp);
    this.studyDetailCmp.instance._ref = this.studyDetailCmp;
    this.studyDetailCmp.instance.getStudyDetails(this._studyNum);
    this.enableChangebtn = this._globals.enableChange;    
  }
  agencyDetailsClick() {
    this.active=2;
    this.isStudyPanelExpanded  = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(AgencyGuideComponent);
    const agencyGuideComp = this.container.createComponent(comp);
    this.childComponents.push(agencyGuideComp);
    agencyGuideComp.instance._ref = agencyGuideComp;
    agencyGuideComp.instance.getAgencyGuide(this._studyNum);
  }
  phaseDetailsClick() {
    this.active=3;
    this.selectedValue = 'Phase_Selected';
    this.isStudyPanelExpanded  = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(PhaseComponent);
    const phaseComp = this.container.createComponent(comp);
    this.childComponents.push(phaseComp);
    phaseComp.instance._ref = phaseComp;
    phaseComp.instance.getPhase(this._studyNum, this.phaseDDValue);
  }
  datesDetailsClick() {
    this.active=4;
    this.selectedValue = 'Date_Selected';
    this.isStudyPanelExpanded  = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(DatesComponent);
    const datesComp = this.container.createComponent(comp);
    this.childComponents.push(datesComp);
    datesComp.instance._ref = datesComp;
    datesComp.instance.getDates(this._studyNum, this.phaseDDValue);
  }
  personnelDetailsClick() {
    this.active=5;
    this.isStudyPanelExpanded  = false;
    this.container.clear();
    const comp = this._cfr.resolveComponentFactory(PersonnelComponent);
    const personnelComp = this.container.createComponent(comp);
    this.childComponents.push(personnelComp);
    personnelComp.instance._ref = personnelComp;
    
    personnelComp.instance.getPersonnel(this._studyNum);
  }
    ngOnInit() {
         this.active=0;
      this.studyVal = new FormGroup({
      _studyNum: new FormControl('', [
        Validators.minLength(4),
       // Validators.required
      ]),
      _title: new FormControl('', [
        Validators.minLength(4),
      //  Validators.maxLength(20),
       // Validators.required
      ]),
      _clientId: new FormControl('', [
        Validators.minLength(4),
       // Validators.required
      ]),
      _financialId: new FormControl('', [
        Validators.minLength(4),
      //  Validators.required
      ]),
      _CompoundId: new FormControl('', [
      ]),
      _AssayMod: new FormControl('', [
      ]),
      _clientName: new FormControl('', [
      ]),
      phaseDDValue: new FormControl('', [
      ])

    });
  }
  changePhaseDetails(phase: any) {
    
    this.changePhaseandDateDetails();
  // this.phaseDetailsClick();
  //   this.datesDetailsClick();
 //   this.phaseDetailChild.getPhase(this._studyNum, phase.phaserowid);
  //  this.dateDetail.getDates(this._studyNum, phase.phaserowid);
  }

  changePhaseandDateDetails()
  {
    switch(this.selectedValue) {

      case 'Phase_Selected':
      this.phaseDetailsClick();
      break;

      case 'Date_Selected':
      this.datesDetailsClick();
      break;

    }
  }
  getStudy() {
    this.butDisabled = true;
    this._studySevice.getStudyNumbers(this._studyNum, this._clientId, this._financialId, this._title).subscribe(resStudyDD => {
            const self = this;
      setTimeout(function() {
        self.setStudyDDValues(resStudyDD);
      }, 100);

    });
  
  }

  onStudyChange() {
  this.studyDetailCmp.instance.setPermissions();
  }
  setPhase(res: any, studyNumber) {
    this.phaseValuesDD = res;
    this.phaseDDValue = this.phaseValuesDD.length > 0 ? this.phaseValuesDD[0].phaserowid : '';
  }
filterItem(filterValue) {
  filterValue = filterValue.trim();
  filterValue = filterValue.toLowerCase();
  this.study = this.study.filter( item => item.StudyId.toLowerCase().indexOf(filterValue.toLowerCase()) > -1);
}
  setStudyDDValues(resStudyDD) {
    this.study = resStudyDD;
    this.studyDataSource = new MatTableDataSource(resStudyDD);
    this.studyDataSource.paginator = this.studyPaginator;
    this.studyDataSource.sort = this.sort;
    this.studyDataSourceLength = this.studyDataSource.data.length;
    if (resStudyDD.length === 0) {
    this.showInvalidStudymsg ();
    this.isMultipleStudy = true;
    this.isStudyFetched = true;
    this. _isMenuBtnHidden =true;
     }else {
    this._studyNum = resStudyDD.length > 0 ? resStudyDD[0].StudyId : '';
    this._globals.numOfStudy = resStudyDD.length;
    // For proper study number
    if (resStudyDD.length === 1) {
      this.isStudyFetched = false;
      this.isStudySearched = true;
      this. _isMenuBtnHidden =false;
      this.studyNumberDD = resStudyDD;
      this._studySevice.getStudyDetails(this._studyNum).subscribe(resStudy => this.setStudyDetails(resStudy));
    } else {
      this.isStudySearched = true;
      this.isMultipleStudy = false;
      // For partial search on study number
      this.studyNumberDD = resStudyDD;
      this._studySevice.getStudyDetails(this._studyNum).subscribe(resStudy => this.setStudyDetails(resStudy));
   //   this.studyDetailChild.getStudyDetails(this._studyNum);
    }

    this._studySevice.getPhaseValues(this._studyNum).
    subscribe(resPhaseValues => this.setPhase(resPhaseValues, this._studyNum));
  }
  }
 showInvalidStudymsg() {
     // To clear all the oter field values
     this.onRefine();
     const dialogRef = this.dialog.open(ValidationDialogComponent, {
       width: '500px',
       data : { name: 'No records found. Would you like to modify the current criteria?' },
       disableClose: true
     });
 }
 onEdit(){
  const dialogRef = this.dialog.open(ValidationDialogComponent, {
    width: '500px',
    data : { name: 'Under Implementation' },
    disableClose: true
  });
 }
  setStudyDetails(resStudyDetails) {
    this.studyDetails = resStudyDetails.length > 0 ? resStudyDetails[0] : '';
    this._title = resStudyDetails.length > 0 ? resStudyDetails[0].Title : '';
    this._clientId = resStudyDetails.length > 0 ? resStudyDetails[0].clid : '';
    this._financialId = resStudyDetails.length > 0 ? resStudyDetails[0].FinancialClientID : '';
    this._CompoundId = resStudyDetails.length > 0 ? resStudyDetails[0].CompoundId : '';
    this._AssayMod = resStudyDetails.length > 0 ? resStudyDetails[0].AssayMod : '';
    this._clientName = resStudyDetails.length > 0 ? resStudyDetails[0].Client_Name : '';
    this.studyDetailsDD = resStudyDetails;
  }
  getStudyDetails(studyNumber: any) {
    this._studySevice.getStudyDetails(studyNumber).subscribe(resStudy => this.setStudyDetails(resStudy));
    this._studySevice.getPhaseValues(studyNumber).subscribe(resPhaseValues => this.setPhase(resPhaseValues, studyNumber.StudyId));
  }
  onChange(newValue) {
    this._studyNum = newValue.StudyId;
    this.getStudyDetails(newValue);
  }
  changeNext() {
    let val = this.studyNumberDD.findIndex(o => o.StudyId === this._studyNum);
    if ((val + 1 < this.studyNumberDD.length)) {
      val = val + 1;
      this._studyNum = this.studyNumberDD[val];
      this.onChange(this._studyNum);
    }
  }
  changePrev() {
    let val = this.studyNumberDD.findIndex(o => o.StudyId === this._studyNum);
    if (val > 0) {
      val = val - 1;
      this._studyNum = this.studyNumberDD[val];
      this.onChange(this._studyNum);
    }
  }
  onReset() {
    this.active=0;
    this.studyVal.reset();
    this._studyNum = '';
    this._clientId = '';
    this._financialId = '';
    this._title = '';
    this.phaseValuesDD = null;
    this._globals.numOfStudy = 0;
    this.isStudyFetched = true;
    this.isStudyPanelExpanded = true;
    this.container.clear();
  }
    generateReport() {
    const dialogRef = this.dialog.open(StudyDialogComponent, {
      width: '800px',
      disableClose: true
    });
    dialogRef.componentInstance.studyCode = this._studyNum;

  }

  getValidate() {
      if (this.studyVal.controls._studyNum.valid || this.studyVal.controls._title.valid
      || this.studyVal.controls._clientId.valid || this.studyVal.controls._financialId.valid) {
        this.getStudy();
      }

    }
  onRefine() {
    this.studyNumAfterRefine = this._studyNum;
    this.container.clear();
    this._clientId = '';
    this._financialId = '';
    this._title = '';
    this._AssayMod = '';
    this._clientName = '';
    this._CompoundId = '';
    this._studyNum = this.studyNumAfterRefine;
    this.phaseValuesDD = null;
    this.isStudyFetched = false;
    this._globals.numOfStudy = 0;
    this.container.clear();
  }

//  To filter the data in the grid

applyFilter(filterValue: string) {
  filterValue = filterValue.trim(); // Remove whitespace
  filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
  this.studyDataSource.filter = filterValue;
}


OnStudyClick(studyId) {
  this._studyNum = studyId;
   this.isStudyFetched = false;
   this.isMultipleStudy = true;
   this. isStudySearched = true;
   this._isMenuBtnHidden=false;
  this.getStudyDetails(studyId);
}
onNewPhaseClick() {
  if (this.studyDetails.Status === 'Open' || this.studyDetails.Status === 'Report Amendment') {
    this._studySevice.GetNewPhaseDropDownValues().
    subscribe(resNewPhaseDDValues => this.setNewPhaseDDValues(resNewPhaseDDValues));
}else {
  const dialogRef = this.dialog.open(ValidationDialogComponent, {
      width: '500px',
      disableClose: true,
      data:  { name: 'The Study must be reopened before adding phase.' },
    });
  }
}
setNewPhaseDDValues(newPhaseDDValues) {
  const dialogRef = this.dialog.open(AddPhaseDialogComponent, {
    width: '500px',
    disableClose: true,
    data:  {  newPhaseDDValues },
  });
}

onBackBtnClick() {
  this.onReset();
  this.isStudyFetched = true;
  this.isMultipleStudy = true;
  this. isStudySearched = false;
  this.isStudyPanelExpanded = true;
  this._isMenuBtnHidden=true;
  this.container.clear();
}
}
