import { Component, ViewChild, Input } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Http, Response } from '@angular/http';
import { PhaseService } from './phase.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { Globals } from '../../../shared/globals';

@Component({
  selector: 'app-study-phase',
  templateUrl: './phase.html',
  styleUrls: ['phase.css']
})

export class PhaseComponent {
  @Input() public entity: any;
  displayedColumns = ['Detail', 'Value', 'Comments'];
  phaseDataSourceLength = -1;
  phasedataSource;
  _ref: any;
  @ViewChild(MatPaginator) phasePaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private _phaseSevice: PhaseService,private _globals:Globals) { }


  setPhaseDetailDataSource(res) {
    this.phasedataSource = new MatTableDataSource(res);
    this.phasedataSource.paginator = this.phasePaginator;
    this.phasedataSource.sort = this.sort;
    this.phaseDataSourceLength = this.phasedataSource.data.length;
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.phasedataSource.filter = filterValue;
  }

  getPhase(studyNumber, phaseRowId: string) {
    this._phaseSevice.getPhase(studyNumber, phaseRowId).subscribe(res => {
      this.setPhaseDetailDataSource(res);
    });
  }

  onReset() {
    this.phasedataSource = null;
    this.phaseDataSourceLength = 0;
  }

}

