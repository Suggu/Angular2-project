import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Http, Response } from '@angular/http';
import { AgencyGuideService } from './agency-guide.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { Globals } from '../../../shared/globals';

@Component({
  selector: 'app-agency-guide',
  templateUrl: './agency-guide.html',
  styleUrls:['./agency-guide.component.css']
})
export class AgencyGuideComponent {
  displayedAgencyColumns = ['Agency', 'Comments'];
  displayedGuideColumns = ['Guidelines', 'Comments'];
  agencyDataSource;
  guideDataSource;
  agencyDataSourceLength = -1;
  guideDataSourceLength = -1;
  public agencyLoader = false;
  agency=[];
  guideLine =[];

_ref: any;
  @ViewChild('guidePaginator') guidePaginator: MatPaginator;
  @ViewChild(MatSort) guideSort: MatSort;

  @ViewChild('agencyPaginator') agencyPaginator: MatPaginator;
  @ViewChild(MatSort) agencySort: MatSort;

  constructor(private _agencyGuideService: AgencyGuideService,private _globals:Globals) { }


  setAgencyDetailDataSource(res) {
   this.agency=res;
    this.agencyDataSource = new MatTableDataSource(res);
    this.agencyDataSource.paginator = this.agencyPaginator;
    this.agencyDataSource.sort = this.agencySort;
    this.agencyDataSourceLength = this.agencyDataSource.data.length;
  }

  setGuideDetailDataSource(res) {
    this.guideLine=res;
    this.guideDataSource = new MatTableDataSource(res);
    this.guideDataSource.paginator = this.guidePaginator;
    this.guideDataSource.sort = this.guideSort;
    this.guideDataSourceLength = this.guideDataSource.data.length;
  }

  applyAgencyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.agencyDataSource.filter = filterValue;
  }

  applyGuideFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.guideDataSource.filter = filterValue;
  }
  getAgencyGuide(studyNumber) {
    this.agencyLoader = true;
    this._agencyGuideService.getAgency(studyNumber).subscribe(res => {
      this.agencyLoader = false;
      this.setAgencyDetailDataSource(res);
    });
    this._agencyGuideService.getGuide(studyNumber).subscribe(res => {
      this.agencyLoader = false;
      this.setGuideDetailDataSource(res);
    });
  }

  onReset() {
    this.agencyDataSource = null;
    this.guideDataSource = null;
    this.agencyDataSourceLength = 0;
    this.guideDataSourceLength = 0;

  }

}

