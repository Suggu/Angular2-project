import { HttpClient, HttpResponse,  HttpHeaders  } from '@angular/common/http';
import {RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class StudyDialogService {
    constructor(private http: HttpClient) { }


    private redirectUrl = '/home/app/choose-report';
    private reportUrl = '/home/app/report-parameter';
    private property = new RequestOptions({ withCredentials: true });

    downloadPDF(reportsInputObj): any {
        const headers = new Headers({         });
         const options = new RequestOptions({ headers: headers, withCredentials: true  });
         // Ensure you set the responseType to Blob.
       // options.responseType = ResponseContentType.Blob;
        return this.http.post('http://localhost:50599/api/Reports/GetPdfReport', reportsInputObj, {responseType: 'blob' as 'blob'}).map(
        (res) => {
            const fileBlob = res;
            const blob = new Blob([fileBlob], {
               type: 'application/pdf' // must match the Accept type
            });
            return blob;
        });
    }

    downloadXLS(reportsInputObj): any {
        const headers = new Headers({
            // 'Content-Type': 'application/json',
                        // 'Accept': 'application/pdf'
         });
         const options = new RequestOptions({ headers: headers, withCredentials: true  });
         // Ensure you set the responseType to Blob.
        // options.responseType = ResponseContentType.Blob;
        return this.http.post('http://localhost:50599/api/Reports/GetXlsReport', reportsInputObj, {responseType: 'blob' as 'blob'}).map(
        (res) => {
            const fileBlob = res;
            const blob = new Blob([fileBlob], {
               type: 'application/vnd.ms-excel' // must match the Accept type
            });
            return blob;
        });
    }

    downloadRTF(reportsInputObj): any {
        const headers = new Headers({
            // 'Content-Type': 'application/json',
           // 'Accept': 'application/pdf'
         });
         const options = new RequestOptions({ headers: headers, withCredentials: true  });
         // Ensure you set the responseType to Blob.
        // options.responseType = ResponseContentType.Blob;
        return this.http.post('http://localhost:50599/api/Reports/GetRtfReport', reportsInputObj, {responseType: 'blob' as 'blob'}).map(
        (res) => {
            const fileBlob = res;
            const blob = new Blob([fileBlob], {
               type: 'text/html' // must match the Accept type
            });
            return blob;
        });
    }

    getRedirectUrl(): string { return this.redirectUrl; }
    setRedirectUrl(url: string): void {this.redirectUrl = url;
    }
    getReportUrl(): string {
         return this.reportUrl;
     }
     setReportUrl(url: string): void {
         this.reportUrl = url;
     }
     getReports(moduleName) {
        return this.http.get('http://localhost:50599/api/reports/GetReportNames?moduleName=' + moduleName)
         .map((response: Response) => response);
      }
      getSelectedReportDescription(reportName) {
        return this.http.get('http://localhost:50599/api/reports/GetReportsDescription?reportName=' + reportName)
         .map((response: Response) => response);
      }
      getReportParameterValues(reportName) {
        return this.http.get('http://localhost:50599/api/reports/GetReportParameters?reportName=' + reportName)
         .map((response: Response) => response);
      }
}
