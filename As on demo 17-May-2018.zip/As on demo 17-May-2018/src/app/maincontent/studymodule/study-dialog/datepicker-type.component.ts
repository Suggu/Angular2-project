import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Component, ViewChild } from '@angular/core';
import { FieldType } from '@ngx-formly/material';
import { MatInput } from '@angular/material';
import { DateAdapter } from '@angular/material';
import {NativeDateAdapter} from '@angular/material';

@Component({
  selector: 'app-form-datepicker-type',
  template: `
    <input matInput
      [formControl]="formControl"
      [matDatepicker]="picker"
      [formlyAttributes]="field">
    <ng-template #matSuffix>
      <mat-datepicker-toggle [for]="picker"></mat-datepicker-toggle>
    </ng-template>
    <mat-datepicker #picker></mat-datepicker>
  `,
})
export class DatepickerTypeComponent extends FieldType {
    // constructor(private dateAdapter: DateAdapter<Date>) {
    //     super();
    //    this.dateAdapter.setLocale('en-us'); // MM-DD-YYYY
    //     }

  // Optional: only if you want to rely on `MatInput` implementation
  @ViewChild(MatInput) formFieldControl: MatInput;
}

export class MyDateAdapter extends NativeDateAdapter {
     MY_DATE_FORMATS = {
        parse: {
          dateInput: {month: 'short', year: 'numeric', day: 'numeric'},
        },
        display: {
          dateInput: 'input',
          monthYearLabel: {year: 'numeric', month: 'numeric'},
          dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
          monthYearA11yLabel: {year: 'numeric', month: 'long'},
        },
      };
    format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
      } else {
        return date.toLocaleDateString();
      }
    }
  }











