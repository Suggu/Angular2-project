import { ReportsLoaderComponent } from './../../reportsmodule/reports-loader/reports-loader.component';
import { FloatingActionButton } from 'ng2-floating-action-menu';

import { DialogComponent } from '../../../dialog/dialog.component';
import {Component, Inject, OnInit, OnChanges} from '@angular/core';
import { Http, Response, ResponseContentType } from '@angular/http';
import { StudyDialogService } from './study-dialog.service';
import 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/router/src/config';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { ReportsLoaderComponent } from '../../reportsmodule/reports-loader/reports-loader.component';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormGroup } from '@angular/forms';
import { ValidationDialogComponent } from '../../../shared/validation-dialog/validation-dialog.component';

@Component({
  selector: 'app-study-dialog',
  templateUrl: 'study-dialog.html',
  styleUrls: ['study-dialog.css']
})
export class StudyDialogComponent implements OnInit {
  public name: string;
  public _studyNumber = '';
  studyCode: string;
  public reportLoader = false;
  reportsInputObj: any = null;
  _isReportsSelectionPanelHidden: Boolean = true;
  isPersonalReportsSelected: Boolean = false;
  isSharedReportsSelected: Boolean = false;
  isFormattedReportsSelected: Boolean = false;
  _isReportsinputHidden: Boolean = true;
  _isViewReportsBtnHidden: Boolean = true;
  _selectedReportDesc: 'Report Description';
  reportInputParameters: any;
  reports;
  _selectedDDValue;
  filterValues = [];
  dynamicReportParameters;
  displayData: any = null;
  userFields: FormlyFieldConfig[];
  model: any = {};
  form = new FormGroup({});
  reportsInputModel: any = {};
  config;
  selectedReportType;

  reportsType = [
    {value: 'PersonalReports-0', reportName: 'Personal Reports'},
    {value: 'SharedReports-1', reportName: 'Shared Reports'},
    {value: 'FormattedReports-2', reportName: 'Formatted Reports'}
  ];

 formatType = [
    {value: 'PersonalReports-0', formatName: 'PDF'},
    {value: 'SharedReports-1', formatName: 'XLSX'}  
  ];

 generateButtonDisabled: boolean;

  buttons: Array<FloatingActionButton> = [
    {
      iconClass: 'fa fa-file-excel-o',
      label: 'Download XLS',
      onClick: () => {
        this.downloadXLS();
     },
    },
    {
      iconClass: 'fa fa-file-pdf-o',
      label: 'View PDF',
      onClick: () => {
        this.showPDF();
     },
    }
  ];
  placements = [
    {
      value: 'br',
      key: 'bottom right'
    },
    {
      value: 'bl',
      key: 'bottom left'
    },
    {
      value: 'tr',
      key: 'top right'
    },
    {
      value: 'tl',
      key: 'top left'
    },
  ];
  effects = [
    {
      value: 'mfb-zoomin',
      key: 'Zoom In'
    },
    {
      value: 'mfb-slidein',
      key: 'Slide In + Fade'
    },
    {
      value: 'mfb-fountain',
      key: 'Fountain'
    },
    {
      value: 'mfb-slidein-spring',
      key: 'Slide In (Spring)'
    }
  ];
  toggles = [
    'click',
    'hover'
  ];
  ngOnInit() {
    this.getReports();
    this._selectedDDValue='Report Description';
  }
  constructor(
    public dialogRef: MatDialogRef<StudyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _service: StudyDialogService,
    private _router: Router,
    public dialog: MatDialog) { 
      this.config = {
      placment: 'br',
      effect: 'mfb-zoomin',
      label: 'View Reports',
      iconClass: 'fa fa-newspaper-o  faa-tada animated',
      activeIconClass: 'fa fa-newspaper-o  faa-tada animated',
      toggle: 'click',
      buttons: this.buttons
    };}

    changeReportDetails(report) {
    
      switch(report.reportName)
      {
        case "Personal Reports":
        this.onPersonalReportsClick();
        break;
        case "Shared Reports":
        this.onSharedReportsClick();
        break;
        case "Formatted Reports":
        this.onFormattedReportsClick();
        break;
      }
    }

    changeformatType(format)
    {
    this.selectedReportType=format;
    this.generateButtonDisabled=true;
    }

    generateReport() {
        switch(this.selectedReportType.formatName)
        {
          case "PDF":
          this.showPDF();
          break;
          case "XLSX":
          this.downloadXLS();
          break;
          case "RTF":
          this.downloadRTF();
          break;
        }
      }
    getInputObject() {
      for (var i = 0; i < this.reportInputParameters.length; i++) {
        this.filterValues.push(this.reportInputParameters[i].type)
      
      }
        const reportsInputParamsValue = {
          'ReportName': this._selectedDDValue,
          'Paramvalues': this.reportsInputModel,
          'StudyCode': this.studyCode,
          'Name': 'Study',
          'InputDataType':this.filterValues
        };
        
        return reportsInputParamsValue;
      }
      
      getReports() {
        this._service.getReports('Study').subscribe(
          (res) => {
            this.reports = res;
          }
        );
      }
      getSelectedReportDescription(reportName) {
        this._service.getSelectedReportDescription(reportName).subscribe(
          (res) => {
           this._selectedReportDesc = res ? res : this._selectedDDValue;
          }
        );
      }
      showPDF() {
        this.filterValues = [];
        this.showReportsLoader(true);
            this._service.downloadPDF(this.getInputObject()).subscribe(
          (res) => {
            const fileURL = window.URL.createObjectURL(res);
            window.open(fileURL);
          }
        );
        this.showReportsLoader(false);
      }
      downloadXLS() {
        this.filterValues = [];
        this.showReportsLoader(true);
        this._service.downloadXLS(this.getInputObject()).subscribe(
          (res) => {
            this.reportLoader = false;
            const fileURL = window.URL.createObjectURL(res);
            window.open(fileURL);
          });
          this.showReportsLoader(false);
      }
      downloadRTF() {
        this.filterValues = [];
        this.showReportsLoader(true);
        this._service.downloadRTF(this.getInputObject()).subscribe(
          (res) => {
            const fileURL = window.URL.createObjectURL(res);
            window.open(fileURL);
          });
          this.showReportsLoader(false);
      }
      
     
      // On change event of report type dropdown
      changeInputParameter(report) {
        this.filterValues = [];
        this._isReportsinputHidden=false;
        this.getSelectedReportDescription(this._selectedDDValue);
        this.getReportParameterValues(this._selectedDDValue);
        this.reportsInputModel = {};
      }
      getReportParameterValues(reportName) {
        this._service.getReportParameterValues(reportName).subscribe(resParameterValues => {
          this.setReportParameterValues(resParameterValues);
        });
      }
      setReportParameterValues(resParameterValues) {
        this.reportInputParameters = resParameterValues;
        this.userFields = this.reportInputParameters;
        this._isViewReportsBtnHidden = false;
      }
      
  onPersonalReportsClick() {
    this.isPersonalReportsSelected = true;
    this.showPopUp();
  }
  onSharedReportsClick() {
    this.isSharedReportsSelected = true;
    this.showPopUp();
  }
  onFormattedReportsClick() {
    this._isReportsSelectionPanelHidden = false;
    this.isFormattedReportsSelected = true;
    this._selectedReportDesc = 'Report Description';
  }
  showPopUp() {
    this._selectedDDValue = '';
    this._selectedReportDesc = 'Report Description';
    this._isReportsinputHidden = true;
    this._isReportsSelectionPanelHidden = true;
    const dialogRef = this.dialog.open(ValidationDialogComponent, {
      width: '500px',
      data : { name: 'Under Development' },
      disableClose: true
    });
  }
  showReportsLoader(condition: Boolean) {
    if (condition) {
      const dialogRef = this.dialog.open(ReportsLoaderComponent, {
        width: '500px'
      });
    } 
    else{
      this.dialog.closeAll();
    }
  }
}
