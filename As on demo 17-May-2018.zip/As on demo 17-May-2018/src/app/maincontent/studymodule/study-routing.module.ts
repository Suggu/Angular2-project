
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotAuthorisedComponent } from '../../shared/not-authorized.component';
import { StudyComponent } from './study/study.component';

export const studyRoutes: Routes = [
 // { path: 'study', component: StudyComponent },
 // { path: 'study-details', component: StudyComponent },
  { path: '', component: StudyComponent },
  { path: '**', component: StudyComponent },
  { path: 'not-authorized', component: NotAuthorisedComponent }
];

@NgModule({
  imports: [RouterModule.forChild(studyRoutes)],
  exports: [RouterModule]
})
export class StudyRoutingModule { }

