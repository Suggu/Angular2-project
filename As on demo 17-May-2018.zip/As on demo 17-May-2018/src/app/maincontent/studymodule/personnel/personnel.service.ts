import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../../../shared/app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class PersonnelService {
  constructor(private http: HttpClient) { }
  getPersonnel(studyNumber) {
    return this.http.get(AppConstants.PERSONNEL_URL + 'studyCode=' + studyNumber)
    .map((response: Response) => response);
     // .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
  }
  errorHandler(responseError: Response) {
    console.log(responseError);
    Observable.throw(responseError != null ? responseError : 'Server Error');
  }
}
