import { FedMaskDirective } from './../../reportsmodule/date-mask.directive';
import { Component, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { StudyService } from '../study/study.service';
import { AuthService } from '../../../authentication/services/auth.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { Globals } from '../../../shared/globals';

@Component({
  selector: 'app-study-detail',
  templateUrl: './study-detail.html',
  styles: [`
    .even { background-color: white;width: 69px; }
    .odd { background-color: #ccd0ec;width: 69px; }
    `],
})
export class StudyDetailComponent implements OnInit {
  _ref: any;
  disabled: boolean;
  enableStudyDetailsDate = true;
  expDisabled = false;
  studyDetailDD = [];
  studyDetail = [];
  proposalNumber: any;
  loggedInUser = this.authService.getLoggedInUser();
  maskConfig = {
    mask: [
      new RegExp('\\d'),
      new RegExp('\\d'),
      '/',
      new RegExp('\\d'),
      new RegExp('\\d'),
      '/',
      new RegExp('\\d'),
      new RegExp('\\d'),
      new RegExp('\\d'),
      new RegExp('\\d')
    ],
    showMask: false,
    guide: true,
    placeholderChar: '_'
  };
  Study_Study_protocolsign_change = true;

  Study_Study_studyinitiation_change = true;
  Study_Study_studytermination_change = true;
  Study_Study_finalarchive_change = true;
  constructor(private _studySevice: StudyService,
    private authService: AuthService,
    public _globals: Globals) { }
  ngOnInit() {
    if (this.loggedInUser.role !== 'ADMIN') {
      this.expDisabled = true;
    }
  }
  notauth() {
    if (this.loggedInUser.role !== 'ADMIN') {
      alert('not authorised');
    }
  }

  AssignStudydetails(resStudyDetails) {
    this.studyDetailDD = resStudyDetails;
    this.studyDetail = resStudyDetails[0];
    this.disabled = true;
    this.proposalNumber = resStudyDetails[0].Proposal_Number;
    this.proposalNumber = this.proposalNumber.split(',');
  }

  getStudyDetails(studyNumber) {
    this._studySevice.getStudyDetails(studyNumber).subscribe(resStudy => {
      this.AssignStudydetails(resStudy);

    });
  }

  setPermissions() {
    this.Study_Study_protocolsign_change = this._globals.Study_Study_protocolsign_change;
    this.Study_Study_studyinitiation_change = this._globals.Study_Study_studyinitiation_change;
    this.Study_Study_studytermination_change = this._globals.Study_Study_studytermination_change;
    this.Study_Study_finalarchive_change = this._globals.Study_Study_finalarchive_change;
  }

  onReset() {
    this.studyDetailDD = [];
    this.studyDetail = [];
  }

}

