import { Component, ViewChild, Input } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Http, Response } from '@angular/http';
import { DatesService } from './dates.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { Globals } from '../../../shared/globals';

@Component({
  selector: 'app-study-dates',
  templateUrl: './dates.html',
  styleUrls: ['dates.component.css']
})
export class DatesComponent {
_ref: any;
@Input() public entity: any;

  displayedDateColumns = ['Date Type', 'Sch Start', 'Project Start', 'Act Start',
    'Sch End', 'Project End', 'Act End', 'Client', 'Comments', 'Delete'];

  displayedDateDetailsColumns = ['Detail', 'Value', 'Comments'];

  datesDataSource;
  dates = [];
  dateDetails = [];
  datesDetailDataSource;
  datesDataSourceLength = -1;
  datesDetailDataSourceLength = -1;
  highlightedRows = [];
  @ViewChild('datesPaginator') datesPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('datesDetailPaginator') datesDetailPaginator: MatPaginator;
  @ViewChild(MatSort) datesDetailSort: MatSort;

  constructor(private _datesService: DatesService,private _globals:Globals) { }


  setDatesDataSource(res) {
    this.highlightedRows.push(res["Dates"][0]);
    this.dates = res["Dates"];
    this.datesDataSource = new MatTableDataSource(res["Dates"]);
    this.datesDataSource.paginator = this.datesPaginator;
    this.datesDataSource.sort = this.sort;
    this.datesDataSourceLength = this.datesDataSource.data.length;

    this.datesDetailDataSource = new MatTableDataSource(res["DateDetail"]);
    this.dateDetails=res["DateDetail"];
    this.datesDetailDataSource.paginator = this.datesDetailPaginator;
    this.datesDetailDataSource.sort = this.datesDetailSort;
    this.datesDetailDataSourceLength = this.datesDetailDataSource.data.length;

  }

  applyDateFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.datesDataSource.filter = filterValue;
  }
  applyDateDetailsFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.datesDetailDataSource.filter = filterValue;
  }

  changeDateDetails(date) {
    this.dateDetails = this.dates.filter(dateDetail => dateDetail.DTRowid === date);
    this.datesDetailDataSource = new MatTableDataSource(this.dateDetails);
    this.datesDetailDataSource.paginator = this.datesDetailPaginator;
    this.datesDetailDataSource.sort = this.datesDetailSort;


  }
  getDates(studyNumber: string, phaseRowId: string) {
    this._datesService.getDates(studyNumber, phaseRowId).subscribe(res => {
      this.setDatesDataSource(res);
    });
  }

  onReset() {
    this.datesDataSource = null;
    this.datesDataSourceLength = 0;
    this.datesDetailDataSourceLength = 0;
    this.datesDetailDataSource = null;
  }
}

