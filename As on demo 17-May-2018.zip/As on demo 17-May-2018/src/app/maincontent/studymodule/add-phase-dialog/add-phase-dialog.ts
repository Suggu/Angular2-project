import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Globals } from '../../../shared/globals';

@Component({
  selector: 'app-add-phase-dialog',
  templateUrl: 'add-phase-dialog.html',
  styleUrls : ['./add-phase-dialog.css']
})
export class AddPhaseDialogComponent implements OnInit {
  newPhaseDDValues;
  mask = [/[0-9]/];
  addNewPhaseForm: FormGroup;
  _phaseType;
  _phaseValue;
  _interval = 1;
  _deptCode;
  constructor(
    private _globals:Globals,
    public dialogRef: MatDialogRef<AddPhaseDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.newPhaseDDValues = this.data.newPhaseDDValues;
    this._phaseType = this.newPhaseDDValues.PhaseType.PHASETYPE;
    this._phaseValue = this.newPhaseDDValues.IntervalType.INTERVALTYPETXT;
    this._deptCode = this.newPhaseDDValues.CostCenter.CC;

    /* Form Validation */
    this.addNewPhaseForm = new FormGroup({
      _phaseType: new FormControl('', [
        Validators.required
      ]),
      _phaseValue: new FormControl('', [
      ]),
      _deptCode: new FormControl('', [
        Validators.required
      ]),
      _interval: new FormControl('', [
      ])
    });

  }
  onAddNewPhaseClick() {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
