import { ProposalModule } from './maincontent/proposalmodule/proposal.module';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, RouterLinkActive } from '@angular/router';
import { StudyModule } from './maincontent/studymodule/study.module';
import { UnderDevComponent } from './shared/underdev.component';
import { NotAuthorisedComponent } from './shared/not-authorized.component';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { HomeComponent } from './home.component';
import { AppComponent } from './app.component';
import { ReportsModule } from '../app/maincontent/reportsmodule/reports.module';


export const appRoutes: Routes = [
  {
    path: 'home', component: HomeComponent,
    children: [
      { path: 'login', component: LoginComponent },
      {
        path: 'app', component: AppComponent, // canActivateChild: [ AuthGuardService ],
        children: [
          { path: 'study', loadChildren: 'app/maincontent/studymodule/study.module#StudyModule',
        data: { roles: ['STUDY'] }  },
          { path: 'proposal', loadChildren: 'app/maincontent/proposalmodule/proposal.module#ProposalModule', },
          { path: 'contact-report', component: UnderDevComponent },
          { path: 'reports', loadChildren: 'app/maincontent/reportsmodule/reports.module#ReportsModule',
       data: { roles: ['REPORTS'] }  },
          { path: 'client', component: UnderDevComponent },
          { path: 'admin', component: UnderDevComponent, canActivate: [AuthGuardService],
          data: { roles: ['ADMIN', 'REPORTS', 'STUDY'] }  },
          { path: 'not-authorized', component: NotAuthorisedComponent },
          { path: '', redirectTo: 'study', pathMatch: 'full' },
         { path: '**', redirectTo: 'study', pathMatch: 'full' },
        ]//    canActivate: [ AuthGuardService],
      },
     { path: '', redirectTo: 'login', pathMatch: 'full' },
     { path: '**', redirectTo: 'login', pathMatch: 'full' }
    ]
  },

 { path: '', redirectTo: 'home', pathMatch: 'full' },
 { path: '**', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
     // { useHash: true }
    )
  ],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AppRoutingModule { }

