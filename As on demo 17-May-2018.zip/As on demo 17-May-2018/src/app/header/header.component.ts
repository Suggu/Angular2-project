import { Component, Input, HostListener } from '@angular/core';
import { Globals } from '../shared/globals';
import { AuthCookie } from '../authentication/services/auth-cookie.service';
import { Router, ActivatedRoute } from '@angular/router';
import { OnInit } from 'ng-bootstrap-form-validation/node_modules/@angular/core/src/metadata/lifecycle_hooks';
import {  HintService} from 'angular-custom-tour'

@Component({
  selector: 'app-header',
  templateUrl: './header.html',
  styleUrls:['header.component.css']

})
export class HeaderComponent implements OnInit {

  // To clear the cookie while closing the window directly
  @HostListener('window:unload', ['$event'])
  @Input() userFullName: string;
  private redirectUrl = '/home/login';

  constructor(private _globals: Globals,
    private _authCookie: AuthCookie,
    private router: Router,public hintService: HintService ) { }
  ngOnInit() {
    this.userFullName = this._globals.fullname;
    // this._globals.fullname;
  }
  handleUnload(event) {

    this.logout();
  }
  logout() {
    
    this._authCookie.deleteAuth();
    this.router.navigate([this.redirectUrl]);
  }
  onHelpClick(){

  }
}
