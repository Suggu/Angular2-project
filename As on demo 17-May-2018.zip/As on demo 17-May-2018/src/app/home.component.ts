import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';
import { Router, RouterEvent, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { Globals } from './shared/globals';
import { AuthCookie } from './authentication/services/auth-cookie.service';
import { MatDialogModule, MatDialog } from '@angular/material';
import { LoginLoaderComponent } from './login/login-loader/login-loader.component';
import { NgxPermissionsService } from 'ngx-permissions';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})

export class HomeComponent implements OnInit {
  showLoader: boolean;
  private redirectUrl = '/home/app/study';

  response:any;
  cookieValue:any;

  constructor(
    private _ADAuthService: HomeService,
    private router: Router,
    private _globals: Globals,
    private _authCookie: AuthCookie,
    public dialog: MatDialog,
    private permissionsService: NgxPermissionsService
  ) { }

  showLoginLoader(condition: Boolean) {
    
    if (condition) {
    const dialogRef = this.dialog.open(LoginLoaderComponent, {
        width: '500px',
      // data: { name: 'this.name', animal: 'this.anima'}
    });
    // dialogRef.afterClosed().subscribe(result => {
    //   console.log('The dialog was closed');
    // });
  }else {
    this.dialog.closeAll();
  }
  }

  ngOnInit() {
      this.showLoginLoader(true);
      this.cookieValue=this._authCookie.getAuth();
      if(this.cookieValue == '')
      {
       this._ADAuthService.isUserAuthenticated().subscribe(res => {
       res = JSON.parse(res);
       this._authCookie.setAuth(res);
      this.setResponse(res);
       });
      }
      else {
        this.showLoginLoader(true);
        setTimeout(() => {
          this._globals.fullname = this._authCookie.getUserNameValue();
          this.router.navigate([this.redirectUrl]);
          this.showLoginLoader(false);
          }, 6000);

      }
  }
  setResponse(res:any)
  {
   this.response=res;
   this.validateAuth(this.response);
  }

  validateAuth(response)
  {   if (this.response.IsAuthenticated) {
      this.showLoginLoader(false);
    this._authCookie.setAuth(this.response);
    this._globals.fullname = this._authCookie.getUserNameValue();
    const groupName = this._authCookie.getUserRoleValue();
    const permissions = this._authCookie.getUserPermissions();
      this._globals.role = groupName;
      this._globals.userPermissions = permissions;
      this.checkUserPermissions(permissions);
      setTimeout(() => {
        this.router.navigate([this.redirectUrl]);
        this.showLoginLoader(false);
        }, 6000);
    this.router.events.subscribe((event: RouterEvent) => {
     // this.navigationInterceptor(event);
    });
    } else {
      this.showLoginLoader(false);
      this.router.navigate(['/home/login']);
    }

  }
  // Shows and hides the loading spinner during RouterEvent changes
  navigationInterceptor(event: RouterEvent): void {
    if (event instanceof NavigationStart) {
      this.showLoginLoader(true);
    }
    if (event instanceof NavigationEnd) {
      this.showLoginLoader(false);
    }

    // Set loading state to false in both of the below events to hide the spinner in case a request fails
    if (event instanceof NavigationCancel) {
      this.showLoginLoader(false);
    }
    if (event instanceof NavigationError) {
      this.showLoginLoader(false);
    }
  }



  checkUserPermissions(permissions) {
 // tslint:disable-next-line:forin
  for (const per in permissions) {

  switch (permissions[per]) {

    case 'Study_Study_protocolsign_change':
    this._globals.enableChange = false;
    this._globals.Study_Study_protocolsign_change = false;
    break;

    case 'Study_Study_studyinitiation_change':
    this._globals.enableChange = false;
    this._globals.Study_Study_studyinitiation_change = false;
    break;

    case 'Study_Study_studytermination_change':
    this._globals.enableChange = false;
    this._globals.Study_Study_studytermination_change = false;
    break;

    case 'Study_Study_finalarchive_change':
    this._globals.enableChange = false;
    this._globals.Study_Study_finalarchive_change = false;
    break;
  }

}
}

}

